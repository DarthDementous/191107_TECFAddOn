// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR && UNITY_5_6_OR_LATER

using System;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace InspectorGadgets
{
    /// <summary>
    /// A serializable reference to a <see cref="SerializedProperty"/>.
    /// </summary>
    [Serializable]
    public sealed class SerializedPropertyReference
    {
        /************************************************************************************************************************/

        [SerializeField] private Object[] _TargetObjects;
        [SerializeField] private Object _Context;
        [SerializeField] private string _PropertyPath;

        [NonSerialized] private bool _IsInitialised;
        [NonSerialized] private SerializedProperty _TargetProperty;

        private const float Padding = 2;

        /************************************************************************************************************************/

        /// <summary>The target object of the referenced <see cref="SerializedProperty"/>.</summary>
        public Object TargetObject { get => _TargetObjects[0]; }

        /// <summary>The referenced <see cref="SerializedProperty"/>.</summary>
        public SerializedProperty TargetProperty { get => _TargetProperty; }

        /************************************************************************************************************************/

        /// <summary>
        /// Constructs a new <see cref="SerializedPropertyReference"/> which wraps the specified 'property'.
        /// </summary>
        public SerializedPropertyReference(SerializedProperty property)
        {
            _TargetObjects = property.serializedObject.targetObjects;
            _Context = property.serializedObject.context;
            _PropertyPath = property.propertyPath;
        }

        /************************************************************************************************************************/

        private void Initialise()
        {
            if (_IsInitialised)
                return;

            _IsInitialised = true;

            if (!AllTargetObjectExist())
                return;

            if (string.IsNullOrEmpty(_PropertyPath))
                return;

            var obj = new SerializedObject(_TargetObjects, _Context);
            _TargetProperty = obj.FindProperty(_PropertyPath);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true if the specified property and objects match the targets of this reference.
        /// </summary>
        public bool IsTarget(SerializedProperty property, Object[] targetObjects)
        {
            if (_TargetProperty == null ||
                _TargetProperty.propertyPath != property.propertyPath ||
                _TargetObjects.Length != targetObjects.Length)
                return false;

            for (int i = 0; i < _TargetObjects.Length; i++)
            {
                if (_TargetObjects[i] != targetObjects[i])
                    return false;
            }

            return true;
        }

        /************************************************************************************************************************/

        private bool AllTargetObjectExist()
        {
            for (int i = 0; i < _TargetObjects.Length; i++)
            {
                if (_TargetObjects[i] == null)
                    return false;
            }

            return true;
        }

        /// <summary>
        /// Returns true if the target property and all its target objects still exist.
        /// </summary>
        public bool TargetExists()
        {
            Initialise();

            if (!AllTargetObjectExist())
                return false;

            if (_TargetProperty != null)
                return true;

            return false;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Gets the height needed to draw the target property.
        /// </summary>
        public float GetHeight()
        {
            if (_TargetProperty != null)
            {
                return EditorGUI.GetPropertyHeight(_TargetProperty, _TargetProperty.isExpanded) + Padding;
            }

            return 0;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws the target property within the specified 'rect'.
        /// </summary>
        public void Draw(Rect rect)
        {
            Initialise();

            if (_TargetProperty == null)
                return;

            rect.height -= Padding;

            _TargetProperty.serializedObject.Update();

            rect.width += rect.x + 2;

            float width = rect.width;
            float height = rect.height;

            rect.width = Mathf.Ceil(rect.width * 0.3f);
            rect.height = EditorGUIUtility.singleLineHeight;
            EditorGUI.ObjectField(rect, _TargetProperty.serializedObject.targetObject, typeof(Object), true);

            rect.x += rect.width;
            rect.width = width - rect.x;
            rect.height = height;

            GUI.BeginGroup(rect);
            rect.x = rect.y = 0;

            EditorGUI.PropertyField(rect, _TargetProperty, _TargetProperty.isExpanded);

            _TargetProperty.serializedObject.ApplyModifiedProperties();

            GUI.EndGroup();
        }

        /************************************************************************************************************************/
    }
}

#endif