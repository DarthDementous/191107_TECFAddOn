// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR && UNITY_5_6_OR_LATER

using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using Object = UnityEngine.Object;

namespace InspectorGadgets
{
    /************************************************************************************************************************/
    #region Base Visualiser
    /************************************************************************************************************************/

    /// <summary>
    /// Base class for editor windows that help visualise the value of a <see cref="SerializedProperty"/>.
    /// <para></para>
    /// Use <see cref="Visualise{T}"/> to open a window or <see cref="AddVisualiseItem{T}"/> to add a menu item that does so.
    /// </summary>
    public abstract class PropertyVisualiserWindow : EditorWindow
    {
        /************************************************************************************************************************/

        [SerializeField] private SerializedPropertyReference _Target;
        [SerializeField] private bool _RelativeToSelection = true;

        /************************************************************************************************************************/

        /// <summary>
        /// A serializable reference to the <see cref="SerializedProperty"/> being visualised.
        /// </summary>
        public SerializedPropertyReference Target { get => _Target; }

        /************************************************************************************************************************/

        /// <summary>
        /// The name of the window to use as its title.
        /// </summary>
        protected abstract string WindowName { get; }

        /// <summary>
        /// Called at the start of <see cref="OnGUI"/>. If this method returns false, the window will be closed.
        /// </summary>
        protected virtual bool ValidateTarget() { return true; }

        /// <summary>
        /// Override this method to draw gizmos in the scene to visualise the target property.
        /// </summary>
        protected abstract void OnSceneGUI(SceneView sceneView);

        /************************************************************************************************************************/

        /// <summary>
        /// Called when this window is loaded.
        /// Sets the window title and registers the <see cref="DoSceneGUI"/> callback.
        /// </summary>
        protected virtual void OnEnable()
        {
            titleContent = new GUIContent(WindowName);
            SceneView.onSceneGUIDelegate += DoSceneGUI;
        }

        /// <summary>
        /// Called when this window is unloaded.
        /// Unregisters the <see cref="DoSceneGUI"/> callback.
        /// </summary>
        protected virtual void OnDisable()
        {
            SceneView.onSceneGUIDelegate -= DoSceneGUI;
        }

        private void DoSceneGUI(SceneView sceneView)
        {
            if (_Target == null || !_Target.TargetExists())
                return;

            OnSceneGUI(sceneView);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws this window's GUI by calling <see cref="DrawOptions"/> then drawing the target property.
        /// </summary>
        protected void OnGUI()
        {
            if (_Target == null || !_Target.TargetExists() || !ValidateTarget())
            {
                Close();
                return;
            }

            EditorGUIUtility.wideMode = true;
            EditorGUI.BeginChangeCheck();

            // Visualiser Options.

            GUILayout.BeginVertical(GUI.skin.box);
            DrawOptions();
            GUILayout.EndVertical();

            // Target Details.

            GUILayout.BeginVertical(GUI.skin.box);
            GUI.enabled = false;

            EditorGUILayout.ObjectField("Target", _Target.TargetObject, typeof(Object), true);

            EditorGUILayout.LabelField("Property Path", _Target.TargetProperty.propertyPath);

            GUI.enabled = (_Target.TargetObject.hideFlags & HideFlags.NotEditable) != HideFlags.NotEditable;

            _Target.TargetProperty.serializedObject.Update();
            EditorGUILayout.PropertyField(_Target.TargetProperty, _Target.TargetProperty.isExpanded);
            _Target.TargetProperty.serializedObject.ApplyModifiedProperties();

            GUI.enabled = true;
            GUILayout.EndVertical();

#if LITE
            if (GUILayout.Button("Purchase Inspector Gadgets Pro"))
                InspectorGadgetsUtils.OpenInspectorGadgetsProInAssetStore();
#endif

            Repaint();

            if (EditorGUI.EndChangeCheck())
                SceneView.RepaintAll();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws a toggle to control whether the visualisations should be relative to the selected object or not.
        /// Override this method to add additional options to the window.
        /// </summary>
        protected virtual void DrawOptions()
        {
            _RelativeToSelection = EditorGUILayout.Toggle("Relative to Selection", _RelativeToSelection);
        }

        /************************************************************************************************************************/

        /// <summary>
        /// If the "Relative to Selection" toggle is enabled, this property returns the selected object's <see cref="Transform"/>.
        /// </summary>
        protected Transform SelectedTransform
        {
            get
            {
                if (_RelativeToSelection)
                    return Selection.activeTransform;
                else
                    return null;
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Add a "Visualise" menu item which calls <see cref="Visualise{T}"/>
        /// </summary>
        public static void AddVisualiseItem<T>(GenericMenu menu, SerializedProperty property) where T : PropertyVisualiserWindow
        {
            menu.AddItem(new GUIContent("Visualise"), false, () => Visualise<T>(property));
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Opens a <see cref="PropertyVisualiserWindow"/> of the specified type and assigns the specified 'property' as its target.
        /// </summary>
        public static void Visualise<T>(SerializedProperty property) where T : PropertyVisualiserWindow
        {
            var window = CreateInstance<T>();
            window._Target = new SerializedPropertyReference(property);
            window.Show();
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
    #endregion
    /************************************************************************************************************************/
    #region Vector3 Visualiser
    /************************************************************************************************************************/

    /// <summary>
    /// The "Visualise" command in the context menu of a <see cref="Vector3"/> property can be used to open this window
    /// which visualises the property's value in the scene.
    /// </summary>
    public class Vector3VisualiserWindow : PropertyVisualiserWindow
    {
        /************************************************************************************************************************/

        /// <summary>
        /// The name of the window to use as its title.
        /// </summary>
        protected override string WindowName => "Vector3 Visualiser";

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true if the target property is a <see cref="SerializedPropertyType.Vector3"/>.
        /// </summary>
        protected override bool ValidateTarget()
        {
            return Target.TargetProperty.propertyType == SerializedPropertyType.Vector3;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws gizmos in the scene to visualise the target property.
        /// </summary>
        protected override void OnSceneGUI(SceneView sceneView)
        {
            Target.TargetProperty.serializedObject.Update();

            var value = Target.TargetProperty.vector3Value;
            var origin = Vector3.zero;
            var rotation = Quaternion.identity;

            var selection = SelectedTransform;
            if (selection != null)
            {
                value = selection.TransformPoint(value);
                origin = selection.position;
                rotation = selection.rotation;
            }

            Handles.DrawLine(origin, value);

            EditorGUI.BeginChangeCheck();

            value = Handles.PositionHandle(value, rotation);

            if (EditorGUI.EndChangeCheck())
            {
                if (selection != null)
                {
                    value = selection.InverseTransformPoint(value);
                }

                Target.TargetProperty.vector3Value = value;
                Target.TargetProperty.serializedObject.ApplyModifiedProperties();
            }
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
    #endregion
    /************************************************************************************************************************/
    #region Vector2 Visualiser
    /************************************************************************************************************************/

    /// <summary>
    /// The "Visualise" command in the context menu of a <see cref="Vector2"/> property can be used to open this window
    /// which visualises the property's value in the scene.
    /// </summary>
    public class Vector2VisualiserWindow : PropertyVisualiserWindow
    {
        /************************************************************************************************************************/

        private static readonly string[] AxisOptions = { "XY", "XZ" };
        // TODO: custom axis

        [SerializeField] private int _XAxis = 0;
        [SerializeField] private int _YAxis = 1;

        /************************************************************************************************************************/

        /// <summary>
        /// The name of the window to use as its title.
        /// </summary>
        protected override string WindowName => "Vector2 Visualiser";

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true if the target property is a <see cref="SerializedPropertyType.Vector2"/>.
        /// </summary>
        protected override bool ValidateTarget()
        {
            return Target.TargetProperty.propertyType == SerializedPropertyType.Vector2;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws the extra options of this <see cref="PropertyVisualiserWindow"/>.
        /// </summary>
        protected override void DrawOptions()
        {
            base.DrawOptions();

            GUILayout.BeginHorizontal();

            EditorGUILayout.PrefixLabel("Axes");

            int axisMode = (_YAxis == 1) ? 0 : 1;
            int newAxisMode = GUILayout.Toolbar(axisMode, AxisOptions);
            if (axisMode != newAxisMode)
            {
                switch (newAxisMode)
                {
                    case 0:
                        _XAxis = 0;
                        _YAxis = 1;
                        break;
                    case 1:
                        _XAxis = 0;
                        _YAxis = 2;
                        break;
                }
            }

            GUILayout.EndHorizontal();
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws gizmos in the scene to visualise the target property.
        /// </summary>
        protected override void OnSceneGUI(SceneView sceneView)
        {
            Target.TargetProperty.serializedObject.Update();

            var value = Target.TargetProperty.vector2Value;

            var position = new Vector3();
            position[_XAxis] = value.x;
            position[_YAxis] = value.y;

            var origin = Vector3.zero;
            var rotation = Quaternion.identity;

            var selection = SelectedTransform;
            if (selection != null)
            {
                position = selection.TransformPoint(position);
                origin = selection.position;
                rotation = selection.rotation;
            }

            Handles.DrawLine(origin, position);

            EditorGUI.BeginChangeCheck();

            position = Handles.PositionHandle(position, rotation);

            if (EditorGUI.EndChangeCheck())
            {
                if (selection != null)
                {
                    position = selection.InverseTransformPoint(position);
                }

                value.x = position[_XAxis];
                value.y = position[_YAxis];

                Target.TargetProperty.vector2Value = value;
                Target.TargetProperty.serializedObject.ApplyModifiedProperties();
            }
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
    #endregion
    /************************************************************************************************************************/
    #region Float Visualiser
    /************************************************************************************************************************/

    /// <summary>
    /// The "Visualise" command in the context menu of a <see cref="float"/> property can be used to open this window
    /// which visualises the property's value in the scene.
    /// </summary>
    public class FloatVisualiserWindow : PropertyVisualiserWindow
    {
        /************************************************************************************************************************/

        /// <summary>
        /// The name of the window to use as its title.
        /// </summary>
        protected override string WindowName => "Float Visualiser";

        /************************************************************************************************************************/

        /// <summary>
        /// Returns true if the target property is a <see cref="SerializedPropertyType.Float"/>.
        /// </summary>
        protected override bool ValidateTarget()
        {
            return Target.TargetProperty.propertyType == SerializedPropertyType.Float;
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws gizmos in the scene to visualise the target property.
        /// </summary>
        protected override void OnSceneGUI(SceneView sceneView)
        {
            Target.TargetProperty.serializedObject.Update();

            var value = Target.TargetProperty.floatValue;

            var position = Vector3.zero;
            var rotation = Quaternion.identity;

            var selection = SelectedTransform;
            if (selection != null)
            {
                position = selection.position;
                rotation = selection.rotation;
            }

            EditorGUI.BeginChangeCheck();

            value = Handles.RadiusHandle(rotation, position, value);

            if (EditorGUI.EndChangeCheck())
            {
                Target.TargetProperty.floatValue = value;
                Target.TargetProperty.serializedObject.ApplyModifiedProperties();
            }
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
    #endregion
    /************************************************************************************************************************/
}

#endif