// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR && UNITY_5_6_OR_LATER

using System;
using System.Collections.Generic;
using System.Reflection;
using UnityEditor;
using UnityEditorInternal;
using UnityEngine;
using Object = UnityEngine.Object;

namespace InspectorGadgets
{
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class PropertyWatcherWindow : EditorWindow
    {
        /************************************************************************************************************************/

        [SerializeField] private Vector2 _ScrollPosition;
        [SerializeField] private List<SerializedPropertyReference> _Watchers;

        [NonSerialized] private ReorderableList _WatcherDisplayList;

        /************************************************************************************************************************/

        private void OnEnable()
        {
            titleContent = new GUIContent("Watcher");

            _WatcherDisplayList = new ReorderableList(_Watchers, typeof(SerializedPropertyReference))
            {
                headerHeight = 0,
                drawElementCallback = (Rect rect, int index, bool isActive, bool isFocused) => _Watchers[index].Draw(rect),
                elementHeightCallback = (index) => _Watchers[index].GetHeight(),
                displayAdd = false,
            };
        }

        /************************************************************************************************************************/

        private void OnGUI()
        {
            if (_WatcherDisplayList == null || _WatcherDisplayList.list == null)
                OnEnable();

            EditorGUIUtility.wideMode = true;

            if (GUILayout.Button("Clear"))
            {
                _Watchers.Clear();
                Close();
                return;
            }

            for (int i = _Watchers.Count - 1; i >= 0; i--)
            {
                var watcher = _Watchers[i];
                if (!watcher.TargetExists())
                    _Watchers.RemoveAt(i);
            }

            _ScrollPosition = GUILayout.BeginScrollView(_ScrollPosition);
            _WatcherDisplayList.DoLayoutList();
            GUILayout.EndScrollView();

#if LITE
            if (GUILayout.Button("Purchase Inspector Gadgets Pro"))
                InspectorGadgetsUtils.OpenInspectorGadgetsProInAssetStore();
#endif
        }

        /************************************************************************************************************************/

        public static void Watch(SerializedProperty property)
        {
            var window = GetWindow<PropertyWatcherWindow>();

            if (window._Watchers == null)
            {
                window._Watchers = new List<SerializedPropertyReference>();
            }
            else
            {
#if LITE
                const int MaxLiteCount = 3;
                if (window._Watchers.Count >= MaxLiteCount)
                {
                    Debug.LogWarning("<B>Inspector Gadgets Lite</B> only allows up to " + MaxLiteCount +
                        " watches at a time.\nYou can purchase <B>Inspector Gadgets Pro</B> from https://assetstore.unity.com/packages/tools/gui/inspector-gadgets-pro-83013.");
                    return;
                }
#endif

                var targetObjects = property.serializedObject.targetObjects;

                for (int i = 0; i < window._Watchers.Count; i++)
                {
                    if (window._Watchers[i].IsTarget(property, targetObjects))
                        return;
                }
            }

            window._Watchers.Insert(0, new SerializedPropertyReference(property));
        }

        /************************************************************************************************************************/
    }
}

#endif