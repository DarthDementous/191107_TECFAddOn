// Inspector Gadgets // Copyright 2018 Kybernetik //

// This script is based on a concept created by Astral Byte Ltd: http://www.astralbyte.co.nz/code/AutoHideUILayer.cs.
// It has been heavily modified and improved for use in Inspector Gadgets, but the core concept is the same.

#pragma warning disable CS0618 // HACK: Type or member is obsolete: EditorApplication.playmodeStateChanged

#if UNITY_EDITOR

using System.Collections.Generic;
using UnityEditor;
using UnityEngine;
using UnityEngine.EventSystems;

namespace InspectorGadgets
{
    /// <summary>
    /// Automatically hides the UI layer inside the Editor so it doesn't get in the way of 3D objects in scene view.
    ///<para></para>
    /// When any object is selected that is on the UI layer, the layer will be shown and the camera changed to 2D orthographic and zoomed to the current selection.
    ///<para></para>
    /// When any object on another layer is selected, the UI layer will be hidden and the camera changed back to the previous state.
    /// </summary>
    [InitializeOnLoad]
    internal static class AutoHideUI
    {
        /************************************************************************************************************************/

        public const int
            UiLayer = 5;

        private static readonly AutoPrefs.EditorBool
            IsEnabled = InspectorGadgetsUtils.PrefsKeyPrefix + nameof(AutoHideUI),
            IsShowingUI = InspectorGadgetsUtils.PrefsKeyPrefix + nameof(IsShowingUI),
            FocusOnSelection = InspectorGadgetsUtils.PrefsKeyPrefix + nameof(FocusOnSelection),
            Previous2dMode = InspectorGadgetsUtils.PrefsKeyPrefix + nameof(Previous2dMode),
            PreviousOrthographicMode = InspectorGadgetsUtils.PrefsKeyPrefix + nameof(PreviousOrthographicMode);

        public static readonly AutoPrefs.EditorInt
            UILayerMask = new AutoPrefs.EditorInt(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(UILayerMask), 1 << UiLayer);

        private static readonly AutoPrefs.EditorVector3
            PreviousPivot = InspectorGadgetsUtils.PrefsKeyPrefix + nameof(PreviousPivot);

        private static readonly AutoPrefs.EditorQuaternion
            PreviousRotation = InspectorGadgetsUtils.PrefsKeyPrefix + nameof(PreviousRotation);

        private static readonly AutoPrefs.EditorFloat
            PreviousSize = new AutoPrefs.EditorFloat(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(PreviousSize), 1);

        /************************************************************************************************************************/

        static AutoHideUI()
        {
            EditorApplication.delayCall += () =>
            {
                if (!IsEnabled.IsSaved())
                {
                    Selection.selectionChanged += OnFirstRun;
                }
                else if (IsEnabled)
                {
                    Selection.selectionChanged += OnSelectionChanged;
                    EditorApplication.playmodeStateChanged += OnSelectionChanged;

                    if (!EditorApplication.isPlayingOrWillChangePlaymode && !ShouldShow())
                    {
                        Tools.visibleLayers &= ~UILayerMask;
                    }
                }
            };
        }

        /************************************************************************************************************************/

        private static void OnFirstRun()
        {
            if (!ShouldShow())
                return;

            Selection.selectionChanged -= OnFirstRun;

            IsEnabled.Value = false;

            const string FirstRunMessage =
@"Would you like Inspector Gadgets to automatically show and hide the UI layer?
 
On UI selected: show UI layer, enter 2D orthographic mode, and focus the camera on the selected object.

On UI deselected: hide UI layer and return camera to the previous state.

You can turn this feature on/off via the Inspector Gadgets tab in the Edit/Preferences menu.";

            if (EditorUtility.DisplayDialog("Auto Hide UI", FirstRunMessage, "Enable", "Do Nothing"))
            {
                IsEnabled.Value = true;
                EditorApplication.delayCall += Enable;
            }
        }

        /************************************************************************************************************************/

        private static void Enable()
        {
            Selection.selectionChanged += OnSelectionChanged;
            EditorApplication.playmodeStateChanged += OnSelectionChanged;
            OnSelectionChanged();
        }

        /************************************************************************************************************************/

        private static bool ShouldShow()
        {
            var activeGameObject = Selection.activeGameObject;
            if (activeGameObject == null ||
                !activeGameObject.activeInHierarchy ||
                EditorUtility.IsPersistent(activeGameObject))
                return false;

            if (activeGameObject.layer == UiLayer)
                return true;

            if (activeGameObject.GetComponentInParent<UIBehaviour>() ||
                activeGameObject.GetComponentInChildren<UIBehaviour>())
                return true;

            return false;
        }

        /************************************************************************************************************************/

        private static void OnSelectionChanged()
        {
            if (ShouldShow())
                ShowUI();
            else
                HideUI();
        }

        /************************************************************************************************************************/

        private static void ShowUI()
        {
            if (IsShowingUI)
                return;

            var sceneView = SceneView.lastActiveSceneView;
            if (sceneView == null)
                return;

            // Store the current scene view state.
            Previous2dMode.Value = sceneView.in2DMode;
            PreviousOrthographicMode.Value = sceneView.orthographic;
            PreviousPivot.Value = sceneView.pivot;
            PreviousRotation.Value = sceneView.rotation;
            PreviousSize.Value = sceneView.size;

            // Apply UI mode and show the UI layer.
            sceneView.in2DMode = true;
            sceneView.orthographic = true;

            Tools.visibleLayers |= UILayerMask;
            IsShowingUI.Value = true;

            if (!FocusOnSelection)
            {
                var rootRect = Selection.activeTransform.root.GetComponentInChildren<RectTransform>();

                if (rootRect != null)
                {
                    var corners = new Vector3[4];
                    rootRect.GetWorldCorners(corners);

                    var bounds = new Bounds(corners[0], Vector3.zero);
                    bounds.Encapsulate(corners[1]);
                    bounds.Encapsulate(corners[2]);
                    bounds.Encapsulate(corners[3]);

                    float size = Mathf.Max(bounds.size.x / sceneView.camera.aspect, bounds.size.y) * 1.1f;

                    if (size > 0)
                    {
                        // This gives us a much better fit than sceneView.Frame(bounds, false);
                        sceneView.LookAt(bounds.center, rootRect.rotation, size, true, false);
                        return;
                    }
                }
            }

            sceneView.FrameSelected();
        }

        /************************************************************************************************************************/

        private static void HideUI()
        {
            if (!IsShowingUI)
                return;

            var previousPivot = PreviousPivot.Value;
            var previousRotation = PreviousRotation.Value;
            var previousSize = PreviousSize.Value;

            var sceneView = SceneView.lastActiveSceneView;
            if (sceneView == null)
                return;

            // Return to the stored scene view state and hide the UI layer.
            sceneView.in2DMode = Previous2dMode;

            // Only revert the camera state if all the values are actually valid.
            if (IsValidNumber(previousPivot.x) &&
                IsValidNumber(previousPivot.y) &&
                IsValidNumber(previousPivot.z) &&
                IsValidNumber(previousRotation.x) &&
                IsValidNumber(previousRotation.y) &&
                IsValidNumber(previousRotation.z) &&
                IsValidNumber(previousRotation.w) &&
                IsValidNumber(previousSize))
            {
                sceneView.LookAt(previousPivot, previousRotation, previousSize, PreviousOrthographicMode);
            }

            Tools.visibleLayers &= ~UILayerMask;
            IsShowingUI.Value = false;
        }

        /************************************************************************************************************************/

        private static bool IsValidNumber(float value)
        {
            return !float.IsNaN(value) && !float.IsInfinity(value);
        }

        /************************************************************************************************************************/

        [OnEditorQuit]
        private static void OnEditorQuit()
        {
            // If we are currently enabled when the editor closes, show the UI layer in case the next project the user
            // opens doesn't have this script.

            if (IsEnabled)
            {
                Tools.visibleLayers |= UILayerMask;
            }
        }

        /************************************************************************************************************************/
        #region Preferences Window
        /************************************************************************************************************************/

        private static GUIContent
            _EnabledToggleContent,
            _UILayerMaskContent;
        private static GUIContent[] _FocusModes;

        /************************************************************************************************************************/

        public static void DrawPrefs()
        {
            // Enabled.
            if (_EnabledToggleContent == null)
            {
                _EnabledToggleContent = new GUIContent("Auto Hide UI",
                   "If enabled, the UI layer will be automatically hidden until a UI object is selected.");
                _UILayerMaskContent = new GUIContent("UI Layer Mask",
                   "Objects on these layers will trigger the Auto Hide feature.");
            }

            if (IsEnabled.OnGUI(_EnabledToggleContent))
            {
                if (IsEnabled)
                {
                    Enable();
                }
                else
                {
                    Selection.selectionChanged -= OnSelectionChanged;
                    EditorApplication.playmodeStateChanged -= OnSelectionChanged;
                    HideUI();
                    Tools.visibleLayers |= UILayerMask;
                }
            }

            var guiEnabled = GUI.enabled;

            // UI Layer Mask.
            UILayerMask.OnGUI(_UILayerMaskContent, (position, content, style) =>
            {
                return InspectorGadgetsUtils.LayerMaskField(position, content, UILayerMask);
            });

            // Auto Focus Mode.
            if (!IsEnabled)
                GUI.enabled = false;

            if (_FocusModes == null)
            {
                _FocusModes = new GUIContent[]
                {
                    new GUIContent("Root", "When a UI object is first selected, the scene camera will frame the root RectTransform of the selected object."),
                    new GUIContent("Selection", "When a UI object is first selected, the scene camera will frame the selected object."),
                };
            }

            FocusOnSelection.OnGUI(new GUIContent("UI Auto Focus Mode"), (position, label, style) =>
            {
                EditorGUI.PrefixLabel(position, label);

                position.xMin += EditorGUIUtility.labelWidth;

                int previousMode = FocusOnSelection ? 1 : 0;
                return GUI.Toolbar(position, previousMode, _FocusModes) != 0;
            });

            GUI.enabled = guiEnabled;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}

#endif