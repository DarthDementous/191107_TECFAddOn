// Inspector Gadgets // Copyright 2018 Kybernetik //

// The only way to currently determine the name and serialized fields of a missing script is via a custom inspector
// for MonoBehaviour scripts (but not other classes that inherit from it) which needs each object to be selected in
// turn. If anyone knows of a better way to do it, please email kybernetikgames@gmail.com.

#pragma warning disable IDE0031 // Use null propagation
#pragma warning disable IDE0041 // Use 'is null' check

#if UNITY_EDITOR

using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Object = UnityEngine.Object;
using Debug = UnityEngine.Debug;
using UnityEditor;
using System.Reflection;
using UnityEditor.SceneManagement;

namespace InspectorGadgets
{
    /// <summary>[Editor-Only]
    /// Custom inspector for MonoBehaviour but not children, so it should only ever get used on missing scripts.
    /// </summary>
    [CustomEditor(typeof(MonoBehaviour))]
    public class ScriptyHunterEditor : Editor
    {
        /************************************************************************************************************************/

        [NonSerialized]
        private SerializedProperty _ScriptProperty;

        /// <summary>The target's "m_Script" property.</summary>
        protected SerializedProperty ScriptProperty { get { return _ScriptProperty; } }

        [NonSerialized]
        private List<SerializedProperty> _OtherProperties;

        /// <summary>All of the target's properties other than "m_Script".</summary>
        protected List<SerializedProperty> OtherProperties { get { return _OtherProperties; } }

        /************************************************************************************************************************/
        #region Property Gathering and Analysis
        /************************************************************************************************************************/

        /// <summary>
        /// Gathers the target's properties. If its script is missing, this method tries to find other similar scripts.
        /// </summary>
        protected virtual void OnEnable()
        {
            GatherSerializedProperties();

            if (target != null ||
                ScriptyHunterWindow.Instance == null ||
                ScriptyHunterWindow.HasTarget ||
                _ScriptProperty == null)
                return;

            // Get the referenced script's name (if possible).
            var scriptReference = _ScriptProperty.objectReferenceValue;
            string scriptName = scriptReference != null ? scriptReference.name : null;

            var fields = new List<FieldInfo>();

            var scripts = ScriptyHunterWindow.AllScripts;
            var similarityRatings = new int[scripts.Length];

            // Go through each script and calculate its similarity to the missing script.
            for (int i = 0; i < scripts.Length; i++)
            {
                var script = scripts[i];
                var scriptType = script.GetClass();
                if (scriptType == null)
                    continue;

                // Scripts with the same name have max similarity.
                if (script.name == scriptName)
                {
                    similarityRatings[i] = int.MaxValue;
                    continue;
                }

                // Otherwise count the number of fields with names and types matching the serialized properties.
                fields.Clear();
                GatherAllFields(scriptType, fields);
                similarityRatings[i] = CountSimilarFields(fields);
            }

            bool hasSerializedProperties = scriptName != null || _OtherProperties.Count > 0;
            ScriptyHunterWindow.SetScripts(target, _ScriptProperty, hasSerializedProperties, similarityRatings);
        }

        /************************************************************************************************************************/

        private void GatherSerializedProperties()
        {
            _OtherProperties = new List<SerializedProperty>();

            try
            {
                var iterator = serializedObject.GetIterator();

                if (!iterator.NextVisible(true))
                    return;

                do
                {
                    var property = iterator.Copy();
                    if (property.propertyPath == "m_Script")
                        _ScriptProperty = property;
                    else
                        _OtherProperties.Add(property);
                }
                while (iterator.NextVisible(false));
            }
            catch { }
        }

        /************************************************************************************************************************/

        private static void GatherAllFields(Type type, List<FieldInfo> fields)
        {
            var typeFields = type.GetFields(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance);
            for (int i = 0; i < typeFields.Length; i++)
            {
                var field = typeFields[i];
                if (field.IsDefined(typeof(NonSerializedAttribute), true) ||
                    field.IsDefined(typeof(HideInInspector), true))
                    continue;

                if (!field.IsPublic && !field.IsDefined(typeof(SerializeField), true))
                    continue;

                fields.Add(field);
            }
        }

        /************************************************************************************************************************/

        private int CountSimilarFields(List<FieldInfo> fields)
        {
            int count = 0;

            for (int i = 0; i < _OtherProperties.Count; i++)
            {
                var property = _OtherProperties[i];

                for (int j = 0; j < fields.Count; j++)
                {
                    var field = fields[j];

                    if (IsMatch(property, field))
                    {
                        count++;
                        break;
                    }
                }
            }

            return count;
        }

        /************************************************************************************************************************/

        private static bool IsMatch(SerializedProperty property, FieldInfo field)
        {
            if (field.Name != property.propertyPath)
                return false;

            switch (property.propertyType)
            {
                case SerializedPropertyType.Integer: return typeof(int).IsAssignableFrom(field.FieldType) || typeof(uint).IsAssignableFrom(field.FieldType);
                case SerializedPropertyType.Boolean: return field.FieldType == typeof(bool);
                case SerializedPropertyType.Float: return typeof(float).IsAssignableFrom(field.FieldType);
                case SerializedPropertyType.String: return field.FieldType == typeof(string);
                case SerializedPropertyType.Color: return field.FieldType == typeof(Color) || field.FieldType == typeof(Color32);
                case SerializedPropertyType.ObjectReference: return typeof(Object).IsAssignableFrom(field.FieldType);
                case SerializedPropertyType.LayerMask: return field.FieldType == typeof(LayerMask);
                case SerializedPropertyType.Enum: return field.FieldType.IsEnum;// HACK: this doesn't confirm that the enum type actually matches the field. Would need to check property.enumDisplayNames.
                case SerializedPropertyType.Vector2: return field.FieldType == typeof(Vector2);
                case SerializedPropertyType.Vector3: return field.FieldType == typeof(Vector3);
                case SerializedPropertyType.Vector4: return field.FieldType == typeof(Vector4);
                case SerializedPropertyType.Rect: return field.FieldType == typeof(Rect);
                case SerializedPropertyType.Generic: return field.FieldType.HasElementType || typeof(IEnumerable).IsAssignableFrom(field.FieldType);
                case SerializedPropertyType.Character: return field.FieldType == typeof(char);
                case SerializedPropertyType.AnimationCurve: return field.FieldType == typeof(AnimationCurve);
                case SerializedPropertyType.Bounds: return field.FieldType == typeof(Bounds);
                case SerializedPropertyType.Gradient: return field.FieldType == typeof(Gradient);
                case SerializedPropertyType.Quaternion: return field.FieldType == typeof(Quaternion);
                case SerializedPropertyType.Vector2Int: return field.FieldType == typeof(Vector2Int);
                case SerializedPropertyType.Vector3Int: return field.FieldType == typeof(Vector3Int);
                case SerializedPropertyType.RectInt: return field.FieldType == typeof(RectInt);
                case SerializedPropertyType.BoundsInt: return field.FieldType == typeof(BoundsInt);

                default:
                case SerializedPropertyType.ArraySize:
                case SerializedPropertyType.ExposedReference:
                case SerializedPropertyType.FixedBufferSize:
                    break;
            }

            return false;
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>
        /// Draws the target's inspector with a message indicating that the script is missing.
        /// </summary>
        public override void OnInspectorGUI()
        {
            if (target != null)
            {
                base.OnInspectorGUI();
                return;
            }

            serializedObject.Update();

            // Draw the script field and a help box.

            GUI.enabled = true;

            EditorGUILayout.PropertyField(_ScriptProperty, true);

            EditorGUILayout.HelpBox(EditorUtility.scriptCompilationFailed ?
                "The associated script can not be loaded. Please fix any compile errors and assign a valid script." :
                "The associated script can not be loaded. Please assign a valid script.", MessageType.Warning);

            // Draw all other serialized properties disabled.
            GUI.enabled = false;
            for (int i = 0; i < _OtherProperties.Count; i++)
            {
                EditorGUILayout.PropertyField(_OtherProperties[i], true);
            }
            GUI.enabled = true;

            // Apply modifications in case the user dragged a new script into the script field.
            serializedObject.ApplyModifiedProperties();

            if (GUILayout.Button("Remove Component"))
            {
                EditorApplication.delayCall += () =>
                {
                    Undo.DestroyObjectImmediate(target);
                    UnityEditorInternal.InternalEditorUtility.RepaintAllViews();
                };
            }

            if (GUILayout.Button("Find and Fix Missing Scripts"))
            {
                EditorWindow.GetWindow<ScriptyHunterWindow>();
                OnEnable();
            }
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Indicates to the <see cref="ScriptyHunterWindow"/> that the target has been deselected.
        /// </summary>
        protected virtual void OnDisable()
        {
            ScriptyHunterWindow.ClearTarget();
        }

        /************************************************************************************************************************/
    }

    /// <summary>[Editor-Only]
    /// A utility for tracking down and fixing missing script references.
    /// </summary>
    internal sealed class ScriptyHunterWindow : EditorWindow
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/

        public static ScriptyHunterWindow Instance { get; private set; }

        // Gathered Assets.
        private static SceneSetup[] _OriginalSceneSetup;
        private static readonly List<GameObject> MissingPrefabs = new List<GameObject>();
        private static readonly List<string> ScenePaths = new List<string>();
        private static readonly List<GameObject> SceneObjects = new List<GameObject>();
        private static int _SceneObjectIndex;

        // Selected Target Details.
        private static Object _Target;
        private static SerializedProperty _ScriptProperty;
        private static bool _HasSerializedProperties;
        private static int[] _SimilarityRatings;

        [NonSerialized]
        private Vector2 _ScrollPosition;

        /************************************************************************************************************************/

        public static bool HasTarget { get { return _ScriptProperty != null; } }

        /************************************************************************************************************************/

        private static MonoScript[] _AllScripts;

        public static MonoScript[] AllScripts
        {
            get
            {
                if (_AllScripts == null)
                    _AllScripts = MonoImporter.GetAllRuntimeMonoScripts();

                return _AllScripts;
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region EditorWindow Methods
        /************************************************************************************************************************/

        private void OnEnable()
        {
            titleContent = new GUIContent("Scripty Hunter");
            Instance = this;
        }

        /************************************************************************************************************************/

        private void OnGUI()
        {
            if (_OriginalSceneSetup == null)
                GatherScenesAndMissingAsssets();

            if (EditorUtility.scriptCompilationFailed)
                EditorGUILayout.HelpBox("The project currently has compile errors which should be fixed before trying to fix missing script references.", MessageType.Warning);

            if (DoSelectNextButton())
                return;

            if (_ScriptProperty == null)
            {
                DrawGatheredAssets();
                return;
            }

            _ScrollPosition = GUILayout.BeginScrollView(_ScrollPosition);

            EditorGUI.BeginChangeCheck();
            EditorGUILayout.PropertyField(_ScriptProperty, true);
            if (EditorGUI.EndChangeCheck())
            {
                var script = _ScriptProperty.objectReferenceValue as MonoScript;
                if (script != null && script.GetClass() != null)
                    _ScriptProperty.serializedObject.ApplyModifiedProperties();
                else
                    _ScriptProperty.serializedObject.Update();
            }

            if (!ReferenceEquals(_Target, null) && GUILayout.Button("Destroy Component"))
            {
                Undo.DestroyObjectImmediate(_Target);
                ClearTarget();
                SelectNextMissingScript();
                return;
            }

            DoMissingScriptButtons();

            GUILayout.EndScrollView();
        }

        /************************************************************************************************************************/

        private void OnDestroy()
        {
            // If the current scene setup has changed, ask if the user wants to return to what they started with.
            var sceneSetup = EditorSceneManager.GetSceneManagerSetup();
            if (sceneSetup.Length != _OriginalSceneSetup.Length)
                goto ReturnToOriginalSetup;

            for (int i = 0; i < sceneSetup.Length; i++)
            {
                if (sceneSetup[i].path != _OriginalSceneSetup[i].path)
                    goto ReturnToOriginalSetup;
            }

            return;

            ReturnToOriginalSetup:

            if (!EditorUtility.DisplayDialog("Restore Original Scene Setup",
                "Would you like to return to the scene you had open when you opened the Scripty Hunter?", "Restore", "Do Nothing"))
                return;

            if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                return;

            EditorSceneManager.RestoreSceneManagerSetup(_OriginalSceneSetup);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        private static void GatherScenesAndMissingAsssets()
        {
            _OriginalSceneSetup = EditorSceneManager.GetSceneManagerSetup();

            MissingPrefabs.Clear();
            ScenePaths.Clear();

            var guids = AssetDatabase.FindAssets("t:GameObject");
            for (int i = 0; i < guids.Length; i++)
            {
                var path = AssetDatabase.GUIDToAssetPath(guids[i]);
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>(path);
                if (HasAnyMissingComponents(prefab))
                {
                    MissingPrefabs.Add(prefab);
                }
            }

            guids = AssetDatabase.FindAssets("t:SceneAsset");
            for (int i = 0; i < guids.Length; i++)
            {
                var path = AssetDatabase.GUIDToAssetPath(guids[i]);
                ScenePaths.Add(path);
            }
        }

        /************************************************************************************************************************/

        private void DrawGatheredAssets()
        {
            _ScrollPosition = GUILayout.BeginScrollView(_ScrollPosition);

            GUILayout.Label("Prefabs with missing scripts: " + MissingPrefabs.Count, EditorStyles.boldLabel);
            for (int i = 0; i < MissingPrefabs.Count; i++)
            {
                var prefab = MissingPrefabs[i];
                EditorGUILayout.ObjectField(AssetDatabase.GetAssetPath(prefab), prefab, typeof(GameObject), true);
            }

            GUILayout.Label("Scenes: " + ScenePaths.Count, EditorStyles.boldLabel);
            for (int i = 0; i < ScenePaths.Count; i++)
            {
                var scene = ScenePaths[i];
                EditorGUILayout.ObjectField(scene, AssetDatabase.LoadAssetAtPath<SceneAsset>(scene), typeof(SceneAsset), true);
            }

            GUILayout.EndScrollView();

            GUILayout.Label("Assets are removed from these lists as they are selected.\nTo begin again, simply click this button:", EditorStyles.wordWrappedLabel);
            if (GUILayout.Button("Re-Gather Assets"))
            {
                GatherScenesAndMissingAsssets();
            }
        }

        /************************************************************************************************************************/

        private void DoMissingScriptButtons()
        {
            if (_SimilarityRatings == null)
                return;

            var scripts = AllScripts;
            for (int i = scripts.Length - 1; i >= 0; i--)
            {
                int similarity = _SimilarityRatings[i];
                if (similarity <= 0)
                {
                    if (i == scripts.Length - 1)
                    {
                        GUILayout.Label(_HasSerializedProperties ?
                            "No similar scripts found." :
                            "Unable to determine the missing script's name or find any serialized properties to compare other scripts against.",
                            EditorStyles.wordWrappedLabel);
                    }

                    continue;
                }

                var script = scripts[i];
                string prefix = similarity == int.MaxValue ?
                    "[Name Match] " :
                    "[" + similarity + "] ";

                if (GUILayout.Button(prefix + script.name))
                {
                    _ScriptProperty.objectReferenceValue = script;
                    _ScriptProperty.serializedObject.ApplyModifiedProperties();
                    SelectNextMissingScript();
                    return;
                }
            }
        }

        /************************************************************************************************************************/

        private void SelectNextMissingScript()
        {
            _ScriptProperty = null;

            // Next Prefab.

            for (int i = MissingPrefabs.Count - 1; i >= 0; i--)
            {
                var prefab = MissingPrefabs[i];
                MissingPrefabs.RemoveAt(i);
                if (HasAnyMissingComponents(prefab))
                {
                    SelectObject(prefab);
                    return;
                }
            }

            NextScene:

            if (_SceneObjectIndex >= SceneObjects.Count)
            {
                if (ScenePaths.Count > 0)
                {
                    if (!EditorSceneManager.SaveCurrentModifiedScenesIfUserWantsTo())
                        return;

                    var scene = ScenePaths[ScenePaths.Count - 1];
                    ScenePaths.RemoveAt(ScenePaths.Count - 1);
                    EditorSceneManager.OpenScene(scene);

                    GatherSceneObjects();
                    _SceneObjectIndex = -1;

                    // Continue on to pick a scene object.
                }
                else
                {
                    // No scenes left, so we're done.
                    OnDestroy();
                    return;
                }
            }

            NextSceneObject:

            _SceneObjectIndex++;
            if (_SceneObjectIndex < SceneObjects.Count)
            {
                var sceneObject = SceneObjects[_SceneObjectIndex];
                if (HasAnyMissingComponents(sceneObject))
                {
                    SelectObject(sceneObject);
                    return;
                }
                else
                {
                    goto NextSceneObject;
                }
            }
            else
            {
                SceneObjects.Clear();
                goto NextScene;
            }
        }

        private static void GatherSceneObjects()
        {
            SceneObjects.Clear();

            foreach (var gameObject in Resources.FindObjectsOfTypeAll<GameObject>())
            {
                if ((gameObject.hideFlags & HideFlags.HideAndDontSave) != 0)
                    continue;

                if (EditorUtility.IsPersistent(gameObject.transform.root.gameObject))
                    continue;

                SceneObjects.Add(gameObject);
            }
        }

        /************************************************************************************************************************/

        private static void SelectObject(Object target)
        {
            Selection.activeObject = null;
            EditorApplication.delayCall += () =>
                Selection.activeObject = target;
        }

        /************************************************************************************************************************/

        public static void SetScripts(Object target, SerializedProperty scriptProperty, bool hasSerializedProperties, int[] similarityRatings)
        {
            _Target = target;

            _ScriptProperty = scriptProperty;
            _HasSerializedProperties = hasSerializedProperties;
            _SimilarityRatings = similarityRatings;
            Array.Sort(similarityRatings, AllScripts);
            GetWindow<ScriptyHunterWindow>();
        }

        /************************************************************************************************************************/

        public static void ClearTarget()
        {
            _Target = null;
            _ScriptProperty = null;
            _SimilarityRatings = null;
        }

        /************************************************************************************************************************/

        private bool DoSelectNextButton()
        {
            if (MissingPrefabs.Count > 0 || ScenePaths.Count > 0 || _SceneObjectIndex < SceneObjects.Count)
            {
                if (GUILayout.Button("Select Next Missing Script"))
                {
                    SelectNextMissingScript();
                    return true;
                }
            }
            else
            {
                if (GUILayout.Button("Close"))
                {
                    Close();
                    return true;
                }
            }

            return false;
        }

        /************************************************************************************************************************/

        private static readonly List<MonoBehaviour> Components = new List<MonoBehaviour>();

        private static bool HasAnyMissingComponents(GameObject gameObject)
        {
            gameObject.GetComponents<MonoBehaviour>(Components);
            for (int i = 0; i < Components.Count; i++)
            {
                if (Components[i] == null)
                    return true;
            }

            return false;
        }

        /************************************************************************************************************************/
    }
}

#endif