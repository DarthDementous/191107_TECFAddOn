// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_2017_OR_LATER

using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>
    /// Holds a text comment for a <see cref="GameObject"/> which can be viewed and edited in the inspector.
    /// <para></para>
    /// By default, this script sets itself to be excluded from the build.
    /// </summary>
    public sealed class Comment : MonoBehaviour
    {
        /************************************************************************************************************************/

        /// <summary>The text of this comment.</summary>
        public string text;

        /************************************************************************************************************************/

        /// <summary>Returns false if this script is set to <see cref="HideFlags.DontSaveInBuild"/>.</summary>
        public bool IncludeInBuild
        {
            get
            {
                return (hideFlags &= HideFlags.DontSaveInBuild) == 0;
            }
            set
            {
                if (value)
                    hideFlags &= ~HideFlags.DontSaveInBuild;
                else
                    hideFlags |= HideFlags.DontSaveInBuild;
            }
        }

        /************************************************************************************************************************/

        private void Reset()
        {
            IncludeInBuild = false;
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
#if UNITY_EDITOR
    /************************************************************************************************************************/

    [UnityEditor.CustomEditor(typeof(Comment)), UnityEditor.CanEditMultipleObjects]
    internal sealed class CommentEditor : UnityEditor.Editor
    {
        /************************************************************************************************************************/

        private UnityEditor.SerializedProperty _Text;
        private static GUIStyle _TextAreaStyle;

        /************************************************************************************************************************/

        private void OnEnable()
        {
            _Text = serializedObject.FindProperty(nameof(Comment.text));
        }

        /************************************************************************************************************************/

        public override void OnInspectorGUI()
        {
            if (_TextAreaStyle == null)
            {
                _TextAreaStyle =
                    new GUIStyle(UnityEditor.EditorStyles.textArea)
                    {
                        wordWrap = true
                    };
            }

            GUILayout.BeginHorizontal();
            GUILayout.Space(-10);

            UnityEditor.EditorGUI.BeginChangeCheck();
            var text = UnityEditor.EditorGUILayout.TextArea(_Text.stringValue, _TextAreaStyle, GUILayout.ExpandHeight(true));
            if (UnityEditor.EditorGUI.EndChangeCheck())
                _Text.stringValue = InspectorGadgetsUtils.TruncateForLabel(text);

            GUILayout.EndHorizontal();

            // Include in Build.
            bool includeSome = false;
            bool excludeSome = false;
            foreach (var target in targets)
            {
                if ((target as Comment).IncludeInBuild)
                    includeSome = true;
                else
                    excludeSome = true;
            }

            if (includeSome)
            {
                if (excludeSome)
                    UnityEditor.EditorGUI.showMixedValue = true;

                UnityEditor.EditorGUI.BeginChangeCheck();
                includeSome = UnityEditor.EditorGUILayout.Toggle("Include in Build?", true);
                if (UnityEditor.EditorGUI.EndChangeCheck())
                    foreach (var target in targets)
                        (target as Comment).IncludeInBuild = includeSome;

                UnityEditor.EditorGUI.showMixedValue = false;
            }

            serializedObject.ApplyModifiedProperties();
        }

        /************************************************************************************************************************/

        [UnityEditor.MenuItem("CONTEXT/Comment/Include in Build")]
        private static void IncludeInBuild(UnityEditor.MenuCommand command)
        {
            (command.context as Comment).IncludeInBuild = true;
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
#endif
    /************************************************************************************************************************/
}

#endif