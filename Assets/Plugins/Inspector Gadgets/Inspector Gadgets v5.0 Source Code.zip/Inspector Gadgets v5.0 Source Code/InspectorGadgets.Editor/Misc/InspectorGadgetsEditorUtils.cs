// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace InspectorGadgets
{
    public static partial class InspectorGadgetsUtils
    {
        /************************************************************************************************************************/

        internal const string PrefsKeyPrefix = nameof(InspectorGadgets) + ".";

        /************************************************************************************************************************/
        #region Menu Items
        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Component/Find References (in Hierarchy)")]
        private static void FindReferencesInHierarchy(MenuCommand command)
        {
            var gameObject = (command.context as Component).gameObject;

            FindNullReferences(command,
                (property, fieldType) => GetComponentInHierarchy(gameObject, fieldType, property.displayName));
        }

        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Component/Find References (in Scene)")]
        private static void FindReferencesInScene(MenuCommand command)
        {
            FindNullReferences(command,
                (property, fieldType) => GetBestComponent(Object.FindObjectsOfType(fieldType), property.displayName));
        }

        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Component/Find References (in Assets)")]
        private static void FindReferencesIncludingAssets(MenuCommand command)
        {
            FindNullReferences(command,
                (property, fieldType) => FindAssetOfType(fieldType, property.displayName));
        }

        /************************************************************************************************************************/

#if PRO
        [MenuItem("CONTEXT/Component/Show or Hide Script Property")]
        private static void HideScriptProperty(MenuCommand command)
        {
            ComponentEditor.HideScriptProperty.Invert();
        }
#endif

        /************************************************************************************************************************/

        private static void FindNullReferences(MenuCommand command, Func<SerializedProperty, Type, Object> findReference)
        {
            ForEachProperty(new SerializedObject(command.context), (property) =>
            {
                if (property.propertyType != SerializedPropertyType.ObjectReference ||
                    property.objectReferenceValue != null)
                    return;

                var fieldType = SerializedPropertyContextMenu.ObjectReferenceHandler.GetUnderlyingType(property);
                if (fieldType == null)
                    return;

                var reference = findReference(property, fieldType);
                if (reference != null)
                {
                    property.objectReferenceValue = reference;
                    Debug.Log("Found " + property.displayName + ": " + reference, reference);
                }
            });
        }

        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Transform/Inspector Gadgets Manual")]
        internal static void OpenManual()
        {
            string path = Path.GetDirectoryName(typeof(InspectorGadgetsUtils).Assembly.Location) + @"\Inspector Gadgets Manual.pdf";

            if (File.Exists(path))
                EditorUtility.OpenWithDefaultApp(path);
            else
                Debug.LogWarning("Inspector Gadgets Manual file does not exist at " + path);
        }

        /************************************************************************************************************************/
#if PRO// Open Locked Editor Windows.
        /************************************************************************************************************************/

        [MenuItem("Edit/Selection/New Locked Inspector %&S")]
        internal static void NewLockedInspector()
        {
            var window = CreateEditorWindow("UnityEditor.InspectorWindow", out var type);

            var isLocked = type.GetProperty("isLocked", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
            isLocked.GetSetMethod().Invoke(window, new object[] { true });
        }

        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Object/New Locked Inspector %&S")]
        private static void NewLockedInspector(MenuCommand command)
        {
            var selection = Selection.objects;
            Selection.activeObject = command.context;
            NewLockedInspector();
            Selection.objects = selection;
        }

        /************************************************************************************************************************/

        // The window throws exceptions because it fails to initialise properly.
        //[MenuItem("Assets/New Locked Project Browser")]
        //internal static void NewLockedProjectBrowser()
        //{
        //    var window = CreateEditorWindow("UnityEditor.ProjectBrowser", out var type);

        //    var isLocked = type.GetField("m_IsLocked", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        //    isLocked.SetValue(window, true);
        //}

        /************************************************************************************************************************/

        private static EditorWindow CreateEditorWindow(string typeName, out Type type)
        {
            type = typeof(EditorWindow).Assembly.GetType(typeName);
            if (type == null)
            {
                throw new Exception("Unable to find " + typeName + " class in " + typeof(EditorWindow).Assembly.Location);
            }

            var window = ScriptableObject.CreateInstance(type) as EditorWindow;
            window.Show();
            return window;
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/

        [MenuItem("GameObject/Reset Selected Transforms %#Z")]
        private static void ResetSelectedTransforms()
        {
            var gameObjects = Selection.gameObjects;
            if (gameObjects.Length == 0)
                return;

            Undo.RecordObjects(gameObjects, "Reset Transforms");
            for (int i = 0; i < gameObjects.Length; i++)
            {
                Transform transform = gameObjects[i].transform;
                transform.localPosition = Vector3.zero;
                transform.localRotation = Quaternion.identity;
                transform.localScale = Vector3.one;
            }
        }

        /************************************************************************************************************************/

        [MenuItem("CONTEXT/MonoBehaviour/Ping Script Asset")]
        private static void PingScriptAsset(MenuCommand menuCommand)
        {
            PingScriptAsset(menuCommand.context);
        }

        internal static void PingScriptAsset(Object obj)
        {
            MonoScript script;

            if (obj is MonoBehaviour behaviour)
                script = MonoScript.FromMonoBehaviour(behaviour);
            else if (obj is ScriptableObject scriptable)
                script = MonoScript.FromScriptableObject(scriptable);
            else
                return;

            if (script != null)
                EditorGUIUtility.PingObject(script);
        }

        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Transform/Copy Transform Path")]
        private static void CopyTransformPath(MenuCommand menuCommand)
        {
            EditorGUIUtility.systemCopyBuffer = GetTransformPath(menuCommand.context as Transform);
        }

        /************************************************************************************************************************/
        #region Create Editor Script
#if PRO
        /************************************************************************************************************************/

        [MenuItem("CONTEXT/Component/Create Editor Script")]
        private static void CreateEditorScript(MenuCommand command)
        {
            if (!EditorApplication.isPlayingOrWillChangePlaymode)
                CreateEditorScript(command.context);
        }

        internal static void CreateEditorScript(Object target)
        {
            string path = AskForEditorScriptSavePath(target);
            if (path == null)
                return;

            Directory.CreateDirectory(Path.GetDirectoryName(path));

            string editorName = Path.GetFileNameWithoutExtension(path);

            File.WriteAllText(path, BuildEditorScript(target, editorName));

            Debug.Log(editorName + " script created at " + path);

            AssetDatabase.ImportAsset(path);
            AssetDatabase.OpenAsset(AssetDatabase.LoadAssetAtPath<MonoScript>(path));
        }

        /************************************************************************************************************************/

        private static string FindComponentDirectory(Object component)
        {
            if (component is MonoBehaviour behaviour)
            {
                MonoScript script = MonoScript.FromMonoBehaviour(behaviour);
                if (script != null)
                {
                    return Path.GetDirectoryName(AssetDatabase.GetAssetPath(script));
                }
            }

            return "Assets";
        }

        /************************************************************************************************************************/

        private static string AskForEditorScriptSavePath(Object target)
        {
            string path = FindComponentDirectory(target);
            string name = target.GetType().Name;
            string fileName = name + "Editor.cs";

            int dialogResult = EditorUtility.DisplayDialogComplex(
                "Create Editor Script",
                string.Concat("Create Editor Script for ", name, " at ", path, "/", fileName),
                "Create", "Browse", "Cancel");

            switch (dialogResult)
            {
                case 0:// Create.
                    return path + "/" + fileName;

                case 1:// Browse.
                    return EditorUtility.SaveFilePanelInProject("Create Editor Script", fileName, "cs",
                        "Where do you want to save the Editor Script for " + name + "?", path);

                default:// Cancel.
                    return null;
            }
        }

        /************************************************************************************************************************/

        private static string BuildEditorScript(Object target, string editorName)
        {
            var type = target.GetType();

            var text = new StringBuilder();
            text.AppendLine("#if UNITY_EDITOR");
            text.AppendLine();
            text.AppendLine("using UnityEditor;");
            text.AppendLine("using UnityEngine;");
            text.AppendLine();

            bool indent = false;
            if (type.Namespace != null)
            {
                text.Append("namespace ").AppendLine(type.Namespace);
                text.AppendLine("{");
                indent = true;

                text.Append("    ");
            }

            text.Append("[CustomEditor(typeof(");
            text.Append(type.Name);
            text.AppendLine("), true)]");

            if (indent) text.Append("    ");
            text.Append("sealed class ");
            text.Append(editorName);
            text.Append(" : InspectorGadgets.Editor<");
            text.Append(type.Name);
            text.AppendLine(">");

            if (indent) text.Append("    ");
            text.AppendLine("{");

            if (indent) text.Append("    ");
            text.AppendLine("}");

            if (indent) text.AppendLine("}");

            text.AppendLine();
            text.Append("#endif");

            return text.ToString();
        }

        /************************************************************************************************************************/
#endif
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Snapping
        /************************************************************************************************************************/

        /// <summary>[Editor-Only] The Unity editor's "Move X" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float MoveSnapX
        {
            get { return EditorPrefs.GetFloat("MoveSnapX", 1); }
            set { EditorPrefs.SetFloat("MoveSnapX", value); }
        }

        /// <summary>[Editor-Only] The Unity editor's "Move Y" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float MoveSnapY
        {
            get { return EditorPrefs.GetFloat("MoveSnapY", 1); }
            set { EditorPrefs.SetFloat("MoveSnapY", value); }
        }

        /// <summary>[Editor-Only] The Unity editor's "Move Z" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float MoveSnapZ
        {
            get { return EditorPrefs.GetFloat("MoveSnapZ", 1); }
            set { EditorPrefs.SetFloat("MoveSnapZ", value); }
        }

        /// <summary>[Editor-Only] (<see cref="MoveSnapX"/>, <see cref="MoveSnapY"/>, <see cref="MoveSnapZ"/>).</summary>
        public static Vector3 MoveSnapVector
        {
            get
            {
                return new Vector3(MoveSnapX, MoveSnapY, MoveSnapZ);
            }
            set
            {
                MoveSnapX = value.x;
                MoveSnapY = value.y;
                MoveSnapZ = value.z;
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] The Unity editor's "Rotation" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float RotationSnap
        {
            get { return EditorPrefs.GetFloat("RotationSnap", 15); }
            set { EditorPrefs.SetFloat("RotationSnap", value); }
        }

        /// <summary>[Editor-Only] (<see cref="RotationSnap"/>, <see cref="RotationSnap"/>, <see cref="RotationSnap"/>).</summary>
        public static Vector3 RotationSnapVector
        {
            get
            {
                float snap = RotationSnap;
                return new Vector3(snap, snap, snap);
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] The Unity editor's "Scale" snap setting (as specified in Edit/Snap Settings).</summary>
        public static float ScaleSnap
        {
            get { return EditorPrefs.GetFloat("ScaleSnap", 0.1f); }
            set { EditorPrefs.SetFloat("ScaleSnap", value); }
        }

        /// <summary>[Editor-Only] (<see cref="ScaleSnap"/>, <see cref="ScaleSnap"/>, <see cref="ScaleSnap"/>).</summary>
        public static Vector3 ScaleSnapVector
        {
            get
            {
                float snap = ScaleSnap;
                return new Vector3(snap, snap, snap);
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Snaps the given 'value' to a grid with the specified 'snap' size.</summary>
        public static float Snap(float value, float snap)
        {
            return Mathf.Round(value / snap) * snap;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Snaps the given 'position' to the grid (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapPosition(Vector3 position)
        {
            float snap = MoveSnapX;
            position.x = Snap(position.x, snap);

            snap = MoveSnapY;
            position.y = Snap(position.y, snap);

            snap = MoveSnapZ;
            position.z = Snap(position.z, snap);

            return position;
        }

        /// <summary>[Editor-Only] Snaps the given 'position' to the grid on the specified axis (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapPosition(Vector3 position, int axisIndex)
        {
            position[axisIndex] = Snap(position[axisIndex], MoveSnapVector[axisIndex]);
            return position;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Snaps the given 'rotationEuler' to the nearest snap increment on all axes (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapRotation(Vector3 rotationEuler)
        {
            float snap = RotationSnap;
            rotationEuler.x = Snap(rotationEuler.x, snap);
            rotationEuler.y = Snap(rotationEuler.y, snap);
            rotationEuler.z = Snap(rotationEuler.z, snap);
            return rotationEuler;
        }

        /// <summary>[Editor-Only] Snaps the given 'rotationEuler' to the nearest snap increment on the specified axis (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapRotation(Vector3 rotationEuler, int axisIndex)
        {
            rotationEuler[axisIndex] = Snap(rotationEuler[axisIndex], RotationSnap);
            return rotationEuler;
        }

        /// <summary>[Editor-Only] Snaps the given 'rotation' to the nearest snap increment on all axes (as specified in Edit/Snap Settings).</summary>
        public static Quaternion SnapRotation(Quaternion rotation)
        {
            return Quaternion.Euler(SnapRotation(rotation.eulerAngles));
        }

        /// <summary>[Editor-Only] Snaps the given 'rotation' to the nearest snap increment on the specified axis (as specified in Edit/Snap Settings).</summary>
        public static Quaternion SnapRotation(Quaternion rotation, int axisIndex)
        {
            return Quaternion.Euler(SnapRotation(rotation.eulerAngles, axisIndex));
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Snaps the given 'scale' to the nearest snap increment on all axes (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapScale(Vector3 scale)
        {
            float snap = ScaleSnap;
            scale.x = Snap(scale.x, snap);
            scale.y = Snap(scale.y, snap);
            scale.z = Snap(scale.z, snap);
            return scale;
        }

        /// <summary>[Editor-Only] Snaps the given 'scale' to the nearest snap increment on the specified axis (as specified in Edit/Snap Settings).</summary>
        public static Vector3 SnapScale(Vector3 scale, int axisIndex)
        {
            scale[axisIndex] = Snap(scale[axisIndex], ScaleSnap);
            return scale;
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only] Returns true if 'value' is approximately equal to a multiple of 'snap'.</summary>
        public static bool IsSnapped(float value, float snap)
        {
            return Mathf.Approximately(value, Mathf.Round(value / snap) * snap);
        }

        /************************************************************************************************************************/

        [MenuItem("GameObject/Snap to Grid %#X")]
        private static void SnapSelectionToGrid()
        {
            var transforms = Selection.GetTransforms(SelectionMode.TopLevel | SelectionMode.OnlyUserModifiable);

            Undo.RecordObjects(transforms, "Snap to Grid");
            for (int i = 0; i < transforms.Length; i++)
            {
                var transform = transforms[i];
                transform.localPosition = SnapPosition(transform.localPosition);
                transform.localRotation = SnapRotation(transform.localRotation);
                transform.localScale = SnapScale(transform.localScale);
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Draw the target and name of the specified <see cref="Delegate"/>.
        /// </summary>
        public static void DrawDelegate(Rect position, Delegate del)
        {
            float width = position.width;

            position.xMax = EditorGUIUtility.labelWidth + 15;
            if (del.Target is Object obj)
            {
                // If the target is a Unity Object, draw it in an Object Field so the user can click to ping the object.

                using (new EditorGUI.DisabledScope(true))
                {
                    EditorGUI.ObjectField(position, obj, typeof(Object), true);
                }
            }
            else if (del.Method.DeclaringType.IsDefined(typeof(System.Runtime.CompilerServices.CompilerGeneratedAttribute), true))
            {
                // Anonymous Methods draw only their method name.

                position.width = width;

                GUI.Label(position, del.Method.GetNameCS());

                return;
            }
            else if (del.Target == null)
            {
                GUI.Label(position, del.Method.DeclaringType.GetNameCS());
            }
            else
            {
                GUI.Label(position, del.Target.ToString());
            }

            position.x += position.width;
            position.width = width - position.width;

            GUI.Label(position, del.Method.GetNameCS(false));
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Calls the specified 'method' for each M<see cref="SerializedProperty"/> in the 'serializedObject' then
        /// applies any modified properties.
        /// </summary>
        public static void ForEachProperty(SerializedObject serializedObject, Action<SerializedProperty> method)
        {
            var property = serializedObject.GetIterator();
            while (property.Next(true))
            {
                method(property);
            }
            serializedObject.ApplyModifiedProperties();
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Records an Undo snapshot for the target objects of the 'property' then calls the 'function' for each of them.
        /// </summary>
        public static void ForEachTarget(SerializedProperty property, string undoName, Action<Object> function)
        {
            var targetObjects = property.serializedObject.targetObjects;
            Undo.RecordObjects(targetObjects, undoName);

            for (int i = 0; i < targetObjects.Length; i++)
            {
                function(targetObjects[i]);
            }
        }

        /// <summary>[Editor-Only]
        /// Creates a new <see cref="SerializedProperty"/> targeting the same field in each of the target objects of
        /// the specified 'property' and calls the 'function' for each of them, then calls
        /// <see cref="SerializedObject.ApplyModifiedProperties"/>.
        /// </summary>
        public static void ForEachTarget(SerializedProperty property, Action<SerializedProperty> function)
        {
            var targets = property.serializedObject.targetObjects;

            if (targets.Length == 1)
            {
                function(property);
                property.serializedObject.ApplyModifiedProperties();
            }
            else
            {
                string path = property.propertyPath;
                for (int i = 0; i < targets.Length; i++)
                {
                    property = new SerializedObject(targets[i]).FindProperty(path);
                    function(property);
                    property.serializedObject.ApplyModifiedProperties();
                }
            }
        }

        /************************************************************************************************************************/

        /// <summary>[Editor-Only]
        /// Searches through all assets of the specified 'type' and returns the one with a name closest to the
        /// 'nameHint'.
        /// </summary>
        public static Object FindAssetOfType(Type type, string nameHint)
        {
            var guids = AssetDatabase.FindAssets("t:" + type.Name);
            if (guids.Length == 0)
                return null;

            var assets = new Object[guids.Length];
            for (int i = 0; i < guids.Length; i++)
            {
                assets[i] = AssetDatabase.LoadAssetAtPath(AssetDatabase.GUIDToAssetPath(guids[i]), type);
            }
            return GetBestComponent(assets, nameHint);
        }

        /************************************************************************************************************************/

        private static List<string> _LayerNames;
        private static List<int> _LayerNumbers;

        /// <summary>[Editor-Only]
        /// Make a field for layer masks.
        /// </summary>
        public static int LayerMaskField(Rect position, GUIContent label, int layerMask)
        {
            if (_LayerNames == null)
            {
                _LayerNames = new List<string>();
                _LayerNumbers = new List<int>();
            }
            else
            {
                _LayerNames.Clear();
                _LayerNumbers.Clear();
            }

            for (int i = 0; i < 32; i++)
            {
                string layerName = LayerMask.LayerToName(i);
                if (layerName != "")
                {
                    _LayerNames.Add(layerName);
                    _LayerNumbers.Add(i);
                }
            }

            int maskWithoutEmpty = 0;
            for (int i = 0; i < _LayerNumbers.Count; i++)
            {
                if (((1 << _LayerNumbers[i]) & layerMask) > 0)
                    maskWithoutEmpty |= (1 << i);
            }

            maskWithoutEmpty = EditorGUI.MaskField(position, label, maskWithoutEmpty, _LayerNames.ToArray());
            int mask = 0;
            for (int i = 0; i < _LayerNumbers.Count; i++)
            {
                if ((maskWithoutEmpty & (1 << i)) > 0)
                    mask |= (1 << _LayerNumbers[i]);
            }

            return mask;
        }

        /************************************************************************************************************************/
    }
}

#endif