// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_2017_OR_LATER && UNITY_EDITOR && PRO

using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>
    /// Sets the <see cref="Object.hideFlags"/> of the attached <see cref="GameObject"/> to
    /// <see cref="HideFlags.DontSaveInBuild"/> when added and allows the flags to be changed in the inspector.
    /// </summary>
    public sealed class SetHideFlags : MonoBehaviour
    {
        /************************************************************************************************************************/

        private void Reset()
        {
            hideFlags |= HideFlags.DontSaveInBuild;
            gameObject.hideFlags |= HideFlags.DontSaveInBuild;
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/

    [UnityEditor.CustomEditor(typeof(SetHideFlags))]
    internal sealed class SetHideFlagsEditor : Editor<SetHideFlags>
    {
        /************************************************************************************************************************/

        public override void OnInspectorGUI()
        {
            UnityEditor.EditorGUI.BeginChangeCheck();
            var hideFlags = UnityEditor.EditorGUILayout.EnumFlagsField("GameObject HideFlags", Target.gameObject.hideFlags);
            if (UnityEditor.EditorGUI.EndChangeCheck())
                Target.gameObject.hideFlags = (HideFlags)hideFlags;

            if (UnityEditor.EditorUtility.IsPersistent(Target.gameObject))
            {
                GUILayout.Label("Unfortunately this component doesn't work on prefabs.");

                if (GUILayout.Button("Remove Component"))
                    DestroyImmediate(Target);
            }
        }

        /************************************************************************************************************************/
    }

    /************************************************************************************************************************/
}

#endif