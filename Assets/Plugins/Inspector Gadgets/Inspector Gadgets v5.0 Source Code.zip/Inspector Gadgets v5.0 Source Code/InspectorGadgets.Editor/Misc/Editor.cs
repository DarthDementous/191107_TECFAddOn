// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using UnityEditor;
using UnityEngine;
using Object = UnityEngine.Object;

namespace InspectorGadgets
{
#if PRO
    [CustomEditor(typeof(Component), true)]
    [CanEditMultipleObjects]
    internal sealed class ComponentEditor : Editor<Component>
    {
        // This is here because having it in the generic base class would make a new instance for each generic subtype.
        public static readonly AutoPrefs.EditorBool
            HideScriptProperty = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(HideScriptProperty), true);
    }

    [CustomEditor(typeof(ScriptableObject), true)]
    [CanEditMultipleObjects]
    internal sealed class ScriptableObjectEditor : Editor<ScriptableObject> { }

    [CustomEditor(typeof(StateMachineBehaviour), true)]
    [CanEditMultipleObjects]
    internal sealed class StateMachineBehaviourEditor : Editor<StateMachineBehaviour> { }
#endif

    /************************************************************************************************************************/

    /// <summary>[Pro-Only]
    /// Base class to derive custom editors from, with a bunch of additional features on top of Unity's base
    /// <see cref="Editor"/> class.
    /// <para></para>
    /// Doesn't draw the target's "Script" field to save inspector space and reduce clutter.
    /// <para></para>
    /// You can Middle Click anywhere in the inspector area to open the script in your script editor or Ctrl + Middle
    /// Click to open its editor script (or create one if none exists already).
    /// <para></para>
    /// Provides type-casted versions of <see cref="Editor.target"/> and <see cref="Editor.targets"/> so you don't
    /// always have to do it yourself (<see cref="Target"/> and <see cref="Targets"/> respectively).
    /// </summary>
    public abstract class Editor<T> : ScriptyHunterEditor where T : Object
    {
        /************************************************************************************************************************/
        #region Fields and Properties
        /************************************************************************************************************************/
#if PRO
        /************************************************************************************************************************/

        private List<BaseInspectableAttribute> _Inspectables;

        private Action _OnInspectorGUI, _AfterInspectorGUI;

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/

        private bool _HasTarget;
        private T _Target;
        private T[] _Targets;

        /// <summary>The object being inspected (<see cref="Editor.target"/> casted to T).</summary>
        public T Target
        {
            get
            {
                if (!_HasTarget)
                {
                    _HasTarget = true;
                    _Target = target as T;
                }

                return _Target;
            }
        }

        /// <summary>An array of all the objects being inspected (<see cref="Editor.targets"/> casted to T).</summary>
        public T[] Targets
        {
            get
            {
                if (_Targets == null)
                {
                    int count = targets.Length;

                    _Targets = new T[count];

                    _Targets[0] = Target;

                    int i = 1;
                    for (; i < count; i++)
                        _Targets[i] = targets[i] as T;
                }

                return _Targets;
            }
        }

        /************************************************************************************************************************/

        /// <summary>The editor currently being drawn.</summary>
        public static Editor<T> Current { get; private set; }

        /// <summary>The object being inspected (<see cref="Editor.target"/> casted to T) by the editor currently being drawn.</summary>
        public static T CurrentTarget { get { return Current.Target; } }

        /// <summary>An array of all the objects being inspected (<see cref="Editor.targets"/> casted to T) by the editor currently being drawn.</summary>
        public static T[] CurrentTargets { get { return Current.Targets; } }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Initialisation
#if PRO
        /************************************************************************************************************************/

        /// <summary>
        /// Gathers all of the target's inspectables (<see cref="ButtonAttribute"/> and <see cref="LabelAttribute"/>)
        /// and checks for inspector GUI events in the script.
        /// </summary>
        protected override void OnEnable()
        {
            base.OnEnable();

            if (target != null)
            {
                var type = target.GetType();

                if (_Inspectables == null)
                    _Inspectables = BaseInspectableAttribute.Gather(type);

                if (_OnInspectorGUI == null && _AfterInspectorGUI == null)
                {
                    _OnInspectorGUI = TryGetInspectorEvent(type, "OnInspectorGUI", OnInspectorGUIEvents);
                    if (_OnInspectorGUI == null && _AfterInspectorGUI == null)
                        _AfterInspectorGUI = TryGetInspectorEvent(type, "AfterInspectorGUI", AfterInspectorGUIEvents);
                }
            }
        }

        /************************************************************************************************************************/

        private static readonly Dictionary<Type, MethodInfo>
            OnInspectorGUIEvents = new Dictionary<Type, MethodInfo>(),
            AfterInspectorGUIEvents = new Dictionary<Type, MethodInfo>();

        /************************************************************************************************************************/

        private Action TryGetInspectorEvent(Type type, string name, Dictionary<Type, MethodInfo> events)
        {
            var method = TryGetInspectorEventMethod(type, name, events);
            if (method != null)
                return (Action)Delegate.CreateDelegate(typeof(Action), target, method);
            else
                return null;
        }

        private static MethodInfo TryGetInspectorEventMethod(Type type, string name, Dictionary<Type, MethodInfo> events)
        {
            if (!events.TryGetValue(type, out MethodInfo method))
            {
                method = type.GetMethod(
                    name,
                    BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Instance | BindingFlags.Static,
                    null,
                    Type.EmptyTypes,
                    null);

                events.Add(type, method);
            }

            return method;
        }

        /************************************************************************************************************************/
#endif
        #endregion
        /************************************************************************************************************************/
        #region Execution
        /************************************************************************************************************************/

        /// <summary>
        /// Draws the target's regular inspector followed by any extra inspectables
        /// (<see cref="ButtonAttribute"/> and <see cref="LabelAttribute"/>), and responds to Middle
        /// Click events.
        /// <para></para>
        /// To modify or replace just the regular inspector and keep the extra features of <see cref="Editor{T}"/>,
        /// override <see cref="DoPropertiesAndInspectables()"/> instead of <see cref="OnInspectorGUI"/>.
        /// </summary>
        public override void OnInspectorGUI()
        {
#if PRO

            if (target == null || serializedObject.targetObject == null)
            {
                base.OnInspectorGUI();
                return;
            }

            Current = this;

            if (_OnInspectorGUI != null)
                _OnInspectorGUI();
            else
                DoInspectorGUI();

#else
            base.OnInspectorGUI();
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws the inspector GUI of the <see cref="Current"/> editor.
        /// </summary>
        public static void DoInspectorGUI()
        {
#if PRO
            var current = Current;

            current.serializedObject.Update();

            var rect = EditorGUILayout.BeginVertical();

            current.DoPropertiesAndInspectables();

            current._AfterInspectorGUI?.Invoke();

            if (current.serializedObject.ApplyModifiedProperties())
                current.OnPropertyModified();

            EditorGUILayout.EndVertical();
            current.CheckMiddleClick(rect);
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Draws all of the target's serialized properties and inspectables.
        /// </summary>
        public virtual void DoPropertiesAndInspectables()
        {
#if PRO
            DoPropertiesAndInspectables(serializedObject);
#endif
        }

        /// <summary>
        /// Draws all of the target's serialized properties and inspectables.
        /// </summary>
        public void DoPropertiesAndInspectables(SerializedObject serializedObject)
        {
#if PRO
            //DrawDefaultInspector(); return;

            if (!ComponentEditor.HideScriptProperty && ScriptProperty != null)
                EditorGUILayout.PropertyField(ScriptProperty, true);

            int inspectableIndex = 0;

            for (int i = 0; i < OtherProperties.Count; i++)
            {
                // Draw any inspectables with the current index.
                while (inspectableIndex < _Inspectables.Count)
                {
                    var inspectable = _Inspectables[inspectableIndex];
                    if (inspectable.DisplayIndex <= i)
                    {
                        if (inspectable.When.IsNow())
                            inspectable.OnGUI(targets);

                        inspectableIndex++;
                    }
                    else break;
                }

                EditorGUILayout.PropertyField(OtherProperties[i], true);
            }

            // Draw any remaining inspectables.
            while (inspectableIndex < _Inspectables.Count)
            {
                var inspectable = _Inspectables[inspectableIndex];
                if (inspectable.When.IsNow())
                    inspectable.OnGUI(targets);

                inspectableIndex++;
            }

            if (targets.Length == 1)
                DynamicInspector.DrawExtras(target);
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// This method is called if any of the target's serialized members are modified during <see cref="DoInspectorGUI()"/>.
        /// This method does nothing by default.
        /// </summary>
        public virtual void OnPropertyModified() { }

        /************************************************************************************************************************/

        /// <summary>
        /// Checks if the current event is a Middle Click to open the script in the user's script editor application,
        /// or Ctrl + Middle Click to open or create its custom inspector script.
        /// </summary>
        public virtual void CheckMiddleClick(Rect rect)
        {
#if PRO
            rect.yMin -= 16;// Move the top of the rect up to include the component's title bar.
            var currentEvent = Event.current;

            if (currentEvent.type == EventType.MouseUp &&
                currentEvent.button == 2 &&
                rect.Contains(currentEvent.mousePosition))
            {
                currentEvent.Use();

                EditorApplication.delayCall += () =>
                {
                    if (currentEvent.control)// Ctrl + Middle click to open or create the editor script.
                    {
                        var script = MonoScript.FromScriptableObject(this);
                        if (script != null && GetType().Assembly != typeof(Editor<>).Assembly)
                            AssetDatabase.OpenAsset(script);
                        else
                            InspectorGadgetsUtils.CreateEditorScript(target);
                    }
                    else if (currentEvent.shift)// Shift + Middle click to ping the script asset.
                    {
                        InspectorGadgetsUtils.PingScriptAsset(target);
                    }
                    else// Middle click to open the script.
                    {
                        if (target is MonoBehaviour behaviour)
                            AssetDatabase.OpenAsset(MonoScript.FromMonoBehaviour(behaviour));
                        else if (target is ScriptableObject scriptable)
                            AssetDatabase.OpenAsset(MonoScript.FromScriptableObject(scriptable));
                    }
                };
            }
#endif
        }

        /************************************************************************************************************************/

        /// <summary>[Pro-Only]
        /// Draw all <see cref="InspectableAttribute"/> members.
        /// </summary>
        public void DoAllInspectables()
        {
#if PRO
            for (int i = 0; i < _Inspectables.Count; i++)
            {
                var inspectable = _Inspectables[i];
                if (inspectable.When.IsNow())
                    inspectable.OnGUI(targets);
            }
#endif
        }

        /************************************************************************************************************************/

        /// <summary>
        /// Records the current state of the <see cref="Targets"/> so that any subsequent changes can be undone
        /// (reverted back to the recorded state).
        /// </summary>
        public void RecordTargetUndo(string undoName)
        {
            Undo.RecordObjects(targets, undoName);
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}

#endif