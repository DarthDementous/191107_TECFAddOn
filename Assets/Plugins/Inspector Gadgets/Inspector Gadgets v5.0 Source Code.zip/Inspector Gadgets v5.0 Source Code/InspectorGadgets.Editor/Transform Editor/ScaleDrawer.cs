﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

using UnityEditor;
using UnityEngine;

namespace InspectorGadgets
{
    internal sealed class ScaleDrawer : TransformPropertyDrawer
    {
        /************************************************************************************************************************/

        public ScaleDrawer(TransformEditor parentEditor)
            : base(parentEditor,
                  "Scale",
                  "The local scaling of this Game Object relative to the parent.",
                  "The world scale of this Game Object.")
        { }

        /************************************************************************************************************************/

        public override void OnEnable(SerializedObject transform)
        {
            base.OnEnable(transform);
            _MainSerializedProperty = transform.FindProperty("m_LocalScale");
            _XSerializedProperty = _MainSerializedProperty.FindPropertyRelative("x");
            _YSerializedProperty = _MainSerializedProperty.FindPropertyRelative("y");
            _ZSerializedProperty = _MainSerializedProperty.FindPropertyRelative("z");
        }

        /************************************************************************************************************************/

        public override Vector3 GetWorldValue(Transform target) => target.lossyScale;
        public override Vector3 GetLocalValue(Transform target) => target.localScale;

        public override void SetLocalValue(Transform target, Vector3 localScale)
        {
            if (ParentEditor.CurrentFreezeChildTransforms)
                PositionDrawer.CacheChildPositions(target);

            target.localScale = localScale;

            if (ParentEditor.CurrentFreezeChildTransforms)
                PositionDrawer.RevertChildPositions(target);
        }

        public override void SetWorldValue(Transform target, Vector3 worldScale)
        {
            if (ParentEditor.CurrentFreezeChildTransforms)
                PositionDrawer.CacheChildPositions(target);

            if (target.parent != null)
            {
                Vector3 parentWorldScale = target.parent.lossyScale;
                worldScale.x /= parentWorldScale.x;
                worldScale.y /= parentWorldScale.y;
                worldScale.z /= parentWorldScale.z;
            }

            target.localScale = worldScale;

            if (ParentEditor.CurrentFreezeChildTransforms)
                PositionDrawer.RevertChildPositions(target);
        }

        public override GUILayoutOption[] VectorLabelOptions { get { return InternalGUI.ScaleLabelOptions; } }

        public override string UndoName { get { return "Scale"; } }
        public override Vector3 DefaultValue { get { return Vector3.one; } }

        public override Vector3 SnapValues { get { return InspectorGadgetsUtils.ScaleSnapVector; } }
        public override Vector3 SnapValue(Vector3 value)
        {
            return InspectorGadgetsUtils.SnapScale(value);
        }

        /************************************************************************************************************************/

        protected override Vector3 GetDragDirection(Transform target)
        {
            var direction = GetCurrentValue(target);
            if (direction != Vector3.zero)
                return direction;
            else
                return Vector3.one.normalized;
        }

        /************************************************************************************************************************/

        private static readonly GUIContent PasteContentValue = new GUIContent("P");
        public override GUIContent PasteContent => PasteContentValue;

        private static readonly GUIContent SnapContentValue = new GUIContent("S");
        public override GUIContent SnapContent => SnapContentValue;

        protected override string GetSnapTooltip()
        {
            return "(" + InspectorGadgetsUtils.ScaleSnap + ")";
        }

        /************************************************************************************************************************/

        private static readonly NullableVector4 ClipboardValue = new NullableVector4(Vector3.one);
        public override NullableVector4 Clipboard => ClipboardValue;

        /************************************************************************************************************************/

        protected override void DoVectorField()
        {
            DoUniformScaleToggle();

            if (!ParentEditor.UseUniformScale || !HasUniformScale())
            {
                ParentEditor.UseUniformScale = false;
                base.DoVectorField();
            }
            else
            {
                DoUniformScale();
            }
        }

        /************************************************************************************************************************/

        private void DoUniformScaleToggle()
        {
            bool enabled = GUI.enabled;

            if (!ParentEditor.UseUniformScale &&
                !ParentEditor.CurrentIsLocalMode &&
                ParentEditor.Rotation.IsArbitrarilyRotated)
                GUI.enabled = false;

            var content = ParentEditor.UseUniformScale ? InternalGUI.NonUniformScale : InternalGUI.UniformScale;
            if (GUILayout.Button(content, InternalGUI.UniformScaleButtonStyle))
            {
                ParentEditor.UseUniformScale = !ParentEditor.UseUniformScale;
                GUIUtility.hotControl = 0;
                GUIUtility.keyboardControl = 0;

                if (ParentEditor.UseUniformScale)
                    ApplyUniformScale();
            }

            GUI.enabled = enabled;
        }

        /************************************************************************************************************************/

        private bool HasUniformScale()
        {
            return
                DisplayValues.x == DisplayValues.y &&
                DisplayValues.x == DisplayValues.z;
        }

        /************************************************************************************************************************/

        private void ApplyUniformScale()
        {
            RecordTargetsForUndo(UndoName);

            for (int i = 0; i < Targets.Length; i++)
            {
                var target = Targets[i];
                Vector3 scale = GetCurrentValue(target);
                scale.x = scale.y = scale.z = (scale.x + scale.y + scale.z) / 3f;
                SetCurrentValue(target, scale);
            }

            UpdateDisplayValues();
        }

        /************************************************************************************************************************/

        private void DoUniformScale()
        {
            GUILayout.Space(-4);

            //int labelControlID = GUIUtility.GetControlID(FocusType.Passive) + 2;
            //if (!EditorGUIUtility.editingTextField)
            //    HandleVectorLabelHotkeys(labelControlID);

            EditorGUI.BeginChangeCheck();

            float labelWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = InternalGUI.NameLabelWidth - 1;

            DisplayValues.x = MultiFloatField(_MainSerializedProperty, GUI.color, CurrentLabel, DisplayValues.x, InspectorGadgetsUtils.ScaleSnap, 1);

            EditorGUIUtility.labelWidth = labelWidth;

            if (EditorGUI.EndChangeCheck() && DisplayValues.x != null)
            {
                RecordTargetsForUndo(UndoName);

                Vector3 scale = new Vector3(DisplayValues.x.Value, DisplayValues.x.Value, DisplayValues.x.Value);
                for (int i = 0; i < Targets.Length; i++)
                    SetCurrentValue(i, scale);
            }
        }

        /************************************************************************************************************************/
#if UNITY_5_6_OR_LATER
        /************************************************************************************************************************/

        public override void OnPropertyContextMenu(GenericMenu menu, SerializedProperty property)
        {
            AddPropertyNameItem(menu, property);

            int axis = CurrentVectorAxisIndex;
            if (axis < 0)// Vector Label.
            {
                AddVectorClipboardFunctions(menu);

                menu.AddSeparator("");

                SerializedPropertyContextMenu.AddPropertyModifierFunction(menu, property, "Negate", (targetProperty) => targetProperty.vector3Value *= -1);

                SerializedPropertyContextMenu.AddPropertyModifierFunction(menu, property, "Average", (targetProperty) =>
                {
                    var value = targetProperty.vector3Value;
                    value.x = value.y = value.z = (value.x + value.y + value.z) / 3;
                    targetProperty.vector3Value = value;
                });

                var currentEditor = ParentEditor;
                SerializedPropertyContextMenu.AddPropertyModifierFunction(menu, property, "Randomize 0.5-1.5 (Uniform)", (targetProperty) =>
                {
                    var value = Random.value;
                    targetProperty.vector3Value = new Vector3(value, value, value);
                    currentEditor.UseUniformScale = true;
                });
                SerializedPropertyContextMenu.AddPropertyModifierFunction(menu, property, "Randomize 0.5-1.5 (Non-Uniform)", (targetProperty) =>
                {
                    targetProperty.vector3Value = new Vector3(Random.value, Random.value, Random.value);
                });

                AddSnapVectorToGridItem(menu, property);

                SerializedPropertyContextMenu.Vector3MenuHandler.AddLogFunction(menu, property);
            }
            else// X, Y, Z.
            {
                AddFloatClipboardFunctions(menu, axis);

                menu.AddSeparator("");

                SerializedPropertyContextMenu.AddPropertyModifierFunction(menu, property, "Negate", (targetProperty) => targetProperty.floatValue *= -1);
                AddSnapFloatToGridItem(menu, property);
                SerializedPropertyContextMenu.AddPropertyModifierFunction(menu, property, "Randomize 0.5-1.5", (targetProperty) => targetProperty.floatValue = Random.value);

                menu.AddSeparator("");

                SerializedPropertyContextMenu.AddLogValueFunction(menu, property, (targetProperty) => targetProperty.floatValue);
            }
        }

        /************************************************************************************************************************/

        public static void AddSnapVectorToGridItem(GenericMenu menu, SerializedProperty property)
        {
            SerializedPropertyContextMenu.AddPropertyModifierFunction(menu, property, "Snap to Grid (" + InspectorGadgetsUtils.ScaleSnap + ")",
                () => property.vector3Value = InspectorGadgetsUtils.SnapScale(property.vector3Value));
        }

        public static void AddSnapFloatToGridItem(GenericMenu menu, SerializedProperty property)
        {
            SerializedPropertyContextMenu.AddPropertyModifierFunction(menu, property, "Snap to Grid (" + InspectorGadgetsUtils.ScaleSnap + ")",
                () => property.floatValue = InspectorGadgetsUtils.Snap(property.floatValue, InspectorGadgetsUtils.ScaleSnap));
        }

        /************************************************************************************************************************/

        protected override string GetCurrentModePropertyPrefix()
        {
            return ParentEditor.CurrentIsLocalMode ? "localScale" : "lossyScale";
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
        #region Custom Handles
        /************************************************************************************************************************/

        public override void DrawTool(Transform target, Vector3 handlePosition)
        {
            float size = HandleUtility.GetHandleSize(handlePosition);
            EditorGUI.BeginChangeCheck();
            Vector3 newScale = Handles.ScaleHandle(target.localScale, handlePosition, target.rotation, size);
            if (EditorGUI.EndChangeCheck() && GUI.enabled)
            {
                RecordTransformForUndo(target, UndoName);

                Vector3 scaleOffset = target.localScale;
                scaleOffset.x = newScale.x / scaleOffset.x;
                scaleOffset.y = newScale.y / scaleOffset.y;
                scaleOffset.z = newScale.z / scaleOffset.z;

#if PRO
                if (TransformEditor.DrawAllGizmos)
                {
                    ApplyScale(target, handlePosition, scaleOffset);
                }
                else
#endif
                {
                    for (int i = 0; i < Targets.Length; i++)
                    {
                        ApplyScale(Targets[i], handlePosition, scaleOffset);
                    }
                }
            }
        }

        /************************************************************************************************************************/

        private void ApplyScale(Transform target, Vector3 pivot, Vector3 scaleOffset)
        {
            if (ParentEditor.CurrentFreezeChildTransforms)
            {
                PositionDrawer.CacheChildPositions(target);
            }

            if (pivot == target.position)
            {
                target.localScale = Vector3.Scale(target.localScale, scaleOffset);
            }
            else
            {
                Vector3 positionOffset = target.position - pivot;
                target.localScale = Vector3.Scale(target.localScale, scaleOffset);
                target.position = pivot + Vector3.Scale(positionOffset, scaleOffset);
            }

            if (ParentEditor.CurrentFreezeChildTransforms)
            {
                PositionDrawer.RevertChildPositions(target);
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}

#endif