﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR

#define DISABLE_USELESS_BUTTONS

using System;
using System.Text;
using UnityEditor;
using UnityEngine;

namespace InspectorGadgets
{
    internal abstract class TransformPropertyDrawer
    {
        /************************************************************************************************************************/

        const float
            PrimaryColor = 1,
            SecondaryColor = 0.65f;

        protected static readonly Color
            FieldColorX = new Color(PrimaryColor, SecondaryColor, SecondaryColor),
            FieldColorY = new Color(SecondaryColor, PrimaryColor, SecondaryColor),
            FieldColorZ = new Color(SecondaryColor, SecondaryColor, PrimaryColor);

        public static readonly AutoPrefs.EditorBool
            ShowCopyButton = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(ShowCopyButton), true),
            ShowPasteButton = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(ShowPasteButton), true),
            ShowSnapButton = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(ShowSnapButton), true),
            ShowResetButton = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(ShowResetButton), false),
            DisableUselessButtons = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(DisableUselessButtons), true),
            UseFieldColors = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(UseFieldColors), true),
            EmphasizeNonDefaultFields = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(EmphasizeNonDefaultFields), true),
            ItaliciseNonSnappedFields = new AutoPrefs.EditorBool(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(ItaliciseNonSnappedFields), true);

        /************************************************************************************************************************/

        protected readonly TransformEditor
            ParentEditor;
        private readonly GUIContent
            LocalLabel,
            WorldLabel;

        /************************************************************************************************************************/

        public static TransformPropertyDrawer CurrentlyDrawing { get; private set; }

        /************************************************************************************************************************/

        public Transform[] Targets
        {
            get { return ParentEditor.Targets; }
        }

        /************************************************************************************************************************/

        protected GUIContent CurrentLabel
        {
            get { return ParentEditor.CurrentIsLocalMode ? LocalLabel : WorldLabel; }
        }

        /************************************************************************************************************************/

        public TransformPropertyDrawer(TransformEditor parentEditor, string label, string localTooltip, string worldTooltip)
        {
            ParentEditor = parentEditor;
            LocalLabel = new GUIContent(label, localTooltip);
            WorldLabel = new GUIContent(label, worldTooltip);
        }

        /************************************************************************************************************************/

        public void DoProperty()
        {
            CurrentlyDrawing = this;

            int startID = GUIUtility.GetControlID(FocusType.Passive);

            UpdateDisplayValues();

            var position = EditorGUILayout.BeginHorizontal();

            EditorGUI.BeginProperty(position, CurrentLabel, _MainSerializedProperty);
            DoVectorField();
            EditorGUI.EndProperty();

            DoMiniButtons();

            EditorGUILayout.EndHorizontal();

            CheckInspectorClipboardHotkeys(startID);

            CurrentlyDrawing = null;
        }

        /************************************************************************************************************************/
        #region Abstractions
        /************************************************************************************************************************/

        protected SerializedProperty
            _MainSerializedProperty,
            _XSerializedProperty,
            _YSerializedProperty,
            _ZSerializedProperty;

        /************************************************************************************************************************/

        public virtual void OnEnable(SerializedObject transform)
        {
            UpdatePasteTooltip();
            SnapContent.tooltip = "Left Click = Snap " + GetSnapTooltip() + "\nRight Click = Open Snap Settings";
        }

        /************************************************************************************************************************/

        public virtual void OnDisable() { }

        /************************************************************************************************************************/

        public abstract Vector3 GetLocalValue(Transform target);
        public abstract Vector3 GetWorldValue(Transform target);

        public Vector3 GetCurrentValue(Transform target)
        {
            if (ParentEditor.CurrentIsLocalMode)
                return GetLocalValue(target);
            else
                return GetWorldValue(target);
        }

        public Vector3 GetCurrentValue(int targetIndex)
        {
            return GetCurrentValue(Targets[targetIndex]);
        }

        /************************************************************************************************************************/

        public abstract void SetLocalValue(Transform target, Vector3 value);
        public abstract void SetWorldValue(Transform target, Vector3 value);

        public void SetCurrentValue(Transform target, Vector3 value)
        {
            if (ParentEditor.CurrentIsLocalMode)
                SetLocalValue(target, value);
            else
                SetWorldValue(target, value);
        }

        public void SetCurrentValue(int targetIndex, Vector3 value)
        {
            SetCurrentValue(Targets[targetIndex], value);
        }

        public void SetCurrentValue(Transform target, NullableVector4 values)
        {
            Vector3 value = GetCurrentValue(target);
            value = values.ToVector3(value);
            SetCurrentValue(target, value);
        }

        /************************************************************************************************************************/

        public abstract GUIContent PasteContent { get; }
        public abstract GUIContent SnapContent { get; }

        public virtual GUILayoutOption[] VectorLabelOptions { get { return InternalGUI.NameLabelOptions; } }

        public abstract string UndoName { get; }

        public abstract Vector3 DefaultValue { get; }
        public abstract Vector3 SnapValues { get; }
        public abstract Vector3 SnapValue(Vector3 value);

        /************************************************************************************************************************/

        public abstract NullableVector4 Clipboard { get; }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Serialized Property Context Menu
#if UNITY_5_6_OR_LATER
        /************************************************************************************************************************/

        public abstract void OnPropertyContextMenu(GenericMenu menu, SerializedProperty property);

        protected abstract string GetCurrentModePropertyPrefix();

        /************************************************************************************************************************/

        protected void AddPropertyNameItem(GenericMenu menu, SerializedProperty property)
        {
            string name;

            switch (property.propertyType)
            {
                case SerializedPropertyType.Float:
                    name = "float      Transform.";
                    break;
                case SerializedPropertyType.Vector3:
                    name = "Vector3      Transform.";
                    break;
                case SerializedPropertyType.Quaternion:
                    name = "Quaternion      Transform.";
                    break;
                default:
                    return;
            }

            name += GetCurrentModePropertyPrefix();

            if (CurrentVectorAxisIndex >= 0)
            {
                name += ".";
                switch (CurrentVectorAxisIndex)
                {
                    case 0: name += "x"; break;
                    case 1: name += "y"; break;
                    case 2: name += "z"; break;
                }
            }

            menu.AddDisabledItem(new GUIContent(name));
        }

        /************************************************************************************************************************/

        protected void AddVectorClipboardFunctions(GenericMenu menu)
        {
            menu.AddSeparator("");

            UpdateDisplayValues();

            if (!DisplayValues.AnyNull(3))
            {
                menu.AddItem(new GUIContent("Copy " + LocalLabel.text + " (Vector3)"), false, () => { UpdateDisplayValues(); CopyCurrentValueToClipboard(); });
            }

            menu.AddItem(new GUIContent("Paste (public): " + SerializedPropertyContextMenu.Vector3MenuHandler.GetCurrentClipboardString()), false,
                () => PasteValue(SerializedPropertyContextMenu.Vector3MenuHandler.Clipboard));

            menu.AddItem(new GUIContent("Paste (private): " + Clipboard.ToString(3)), false, () => PasteValue(Clipboard));
        }

        /************************************************************************************************************************/

        protected void AddFloatClipboardFunctions(GenericMenu menu, int axis)
        {
            menu.AddSeparator("");

            UpdateDisplayValues();

            switch (axis)
            {
                case 0: AddCopyFloatFunction(menu, DisplayValues.x); break;
                case 1: AddCopyFloatFunction(menu, DisplayValues.y); break;
                case 2: AddCopyFloatFunction(menu, DisplayValues.z); break;
            }

            menu.AddItem(new GUIContent("Paste: " + SerializedPropertyContextMenu.FloatMenuHandler.GetCurrentClipboardString()), false, () =>
            {
                string undoName = "Paste " + LocalLabel.text + ".";

                switch (axis)
                {
                    case 0: undoName += 'x'; break;
                    case 1: undoName += 'y'; break;
                    case 2: undoName += 'z'; break;
                }

                RecordTargetsForUndo(undoName);

                float? value = SerializedPropertyContextMenu.FloatMenuHandler.Clipboard.x;
                if (value != null)
                {
                    for (int i = 0; i < Targets.Length; i++)
                    {
                        var target = Targets[i];
                        if (target == null)
                            continue;

                        Vector3 vector = GetCurrentValue(target);
                        vector[axis] = value.Value;
                        SetCurrentValue(target, vector);
                    }
                }
            });
        }

        /************************************************************************************************************************/

        protected void AddCopyFloatFunction(GenericMenu menu, float? value)
        {
            if (value == null)
                return;

            menu.AddItem(new GUIContent("Copy float"), false, () =>
            {
                SerializedPropertyContextMenu.FloatMenuHandler.SetClipboard(value.Value);
            });
        }

        /************************************************************************************************************************/
#endif
        #endregion
        /************************************************************************************************************************/
        #region Vector Fields
        /************************************************************************************************************************/

        protected virtual void DoVectorField()
        {
            DoVectorLabel();

            EditorGUI.BeginChangeCheck();

            if (UseMiddleClickInLastRect())
            {
                DisplayValues.CopyFrom(DefaultValue);
            }
            else
            {
                MultiVector3Field(DisplayValues);
            }

            if (EditorGUI.EndChangeCheck())
            {
                OnVectorFieldChanged(DisplayValues);

                RecordTargetsForUndo(UndoName);

                for (int i = 0; i < Targets.Length; i++)
                {
                    SetCurrentValue(Targets[i], DisplayValues);
                }
            }
        }

        protected virtual void OnVectorFieldChanged(NullableVector4 values) { }

        /************************************************************************************************************************/

        private static readonly int
            DragControlHint = "LabelDragControl".GetHashCode();

        private void DoVectorLabel()
        {
            InternalGUI.FieldLabelStyle.fontStyle = _MainSerializedProperty.prefabOverride ? FontStyle.Bold : FontStyle.Normal;

            GUILayout.Label(CurrentLabel, InternalGUI.FieldLabelStyle, VectorLabelOptions);

            // Allow the vector label to be dragged.
            var position = GUILayoutUtility.GetLastRect();
            int controlID = GUIUtility.GetControlID(DragControlHint, FocusType.Passive, position);
            HandleDragVectorLabel(position, controlID);

            // This code makes the vector labels selectable so you can Ctrl+C/V them.
            // But it also makes the text selection not work properly in the X field, so it's currently disabled.
            // - The Position/Rotation/Scale labels in the Transform Inspector will now be highlighted in blue when you click on them to show they are selected (just like all other fields).
            // - With any of these labels selected, you can press Ctrl + C/V to copy/paste values just like the [C/P] buttons (paste uses the public clipboard).

            //var position = GUILayoutUtility.GetRect(EditorGUIUtility.labelWidth, EditorGUIUtility.singleLineHeight + 2, VectorLabelOptions);
            //position.y += 2;
            //int controlID = GUIUtility.GetControlID(FocusType.Keyboard, position);
            ////EditorGUI.PrefixLabel(position, controlID, CurrentLabel, InternalGUI.FieldLabelStyle);

            //EditorGUI.HandlePrefixLabel(position, position, CurrentLabel, controlID, InternalGUI.FieldLabelStyle);

            //HandleVectorLabelHotkeys(controlID);
        }

        /************************************************************************************************************************/

        private static Vector3[] _DragStartValues;
        private static Vector3[] _DragDirections;
        private static float[] _DragDistances;

        private void HandleDragVectorLabel(Rect position, int id)
        {
            Event current = Event.current;
            switch (current.GetTypeForControl(id))
            {
                case EventType.MouseDown:// Begin.
                    if (current.button == 0 && position.Contains(current.mousePosition))
                    {
                        EditorGUIUtility.editingTextField = false;
                        GUIUtility.hotControl = id;
                        GUIUtility.keyboardControl = id;
                        Undo.IncrementCurrentGroup();
                        current.Use();

                        int targetCount = Targets.Length;
                        if (_DragStartValues == null || _DragStartValues.Length != targetCount)
                        {
                            _DragStartValues = new Vector3[targetCount];
                            _DragDirections = new Vector3[targetCount];
                            _DragDistances = new float[targetCount];
                        }

                        for (int i = 0; i < targetCount; i++)
                        {
                            var target = Targets[i];
                            if (target == null)
                                continue;

                            var value = GetCurrentValue(target);
                            _DragStartValues[i] = value;

                            _DragDirections[i] = GetDragDirection(target);

                            _DragDistances[i] = 0;
                        }

                        EditorGUIUtility.SetWantsMouseJumping(1);
                    }
                    break;

                case EventType.MouseUp:// End.
                    if (GUIUtility.hotControl == id)// && EditorGUI.s_DragCandidateState != 0)
                    {
                        GUIUtility.hotControl = 0;
                        current.Use();
                        EditorGUIUtility.SetWantsMouseJumping(0);
                    }
                    break;

                case EventType.MouseDrag:// Move.
                    if (GUIUtility.hotControl == id)
                    {
                        RecordTargetsForUndo(UndoName);

                        // This value seems to be what Unity uses for regular dragging on a float field.
                        float delta = HandleUtility.niceMouseDelta * 0.03f;

                        int targetCount = Targets.Length;
                        for (int i = 0; i < targetCount; i++)
                        {
                            var distance = _DragDistances[i] + delta;
                            _DragDistances[i] = distance;

                            var value = _DragStartValues[i] + _DragDirections[i] * distance;

                            if (current.control)
                                value = SnapValue(value);

                            SetCurrentValue(i, value);
                        }

                        UpdateDisplayValues();

                        GUI.changed = true;
                        current.Use();
                    }
                    break;

                case EventType.KeyDown:// Cancel.
                    if (GUIUtility.hotControl == id && current.keyCode == KeyCode.Escape)
                    {
                        RecordTargetsForUndo(UndoName);

                        for (int i = 0; i < Targets.Length; i++)
                        {
                            SetCurrentValue(i, _DragStartValues[i]);
                        }

                        UpdateDisplayValues();

                        GUI.changed = true;
                        GUIUtility.hotControl = 0;
                        current.Use();
                    }
                    break;

                case EventType.Repaint:// Repaint.
                    EditorGUIUtility.AddCursorRect(position, MouseCursor.SlideArrow);
                    break;
            }
        }

        protected abstract Vector3 GetDragDirection(Transform target);

        /************************************************************************************************************************/

        protected static bool UseMiddleClickInLastRect()
        {
            var currentEvent = Event.current;
            if (currentEvent.type == EventType.MouseUp &&
                currentEvent.button == 2 &&
                GUILayoutUtility.GetLastRect().Contains(currentEvent.mousePosition))
            {
                GUI.changed = true;
                currentEvent.Use();
                GUIUtility.keyboardControl = 0;
                return true;
            }
            else return false;
        }

        /************************************************************************************************************************/

        public static int CurrentVectorAxisIndex { get; private set; } = -1;

        protected void MultiVector3Field(NullableVector4 values)
        {
            var labelWidth = EditorGUIUtility.labelWidth;
            EditorGUIUtility.labelWidth = 12;

            Vector3 snapValue = SnapValues;
            Vector3 defaultValue = DefaultValue;

            var color = GUI.color;

            CurrentVectorAxisIndex = 0;
            values.x = MultiFloatField(_XSerializedProperty, FieldColorX, InternalGUI.X, values.x, snapValue.x, defaultValue.x);

            CurrentVectorAxisIndex = 1;
            values.y = MultiFloatField(_YSerializedProperty, FieldColorY, InternalGUI.Y, values.y, snapValue.y, defaultValue.y);

            CurrentVectorAxisIndex = 2;
            values.z = MultiFloatField(_ZSerializedProperty, FieldColorZ, InternalGUI.Z, values.z, snapValue.z, defaultValue.z);

            CurrentVectorAxisIndex = -1;
            GUI.color = color;

            EditorGUIUtility.labelWidth = labelWidth;
        }

        /************************************************************************************************************************/

        protected static readonly NullableVector4 DisplayValues = new NullableVector4();

        protected virtual void UpdateDisplayValues()
        {
            Vector3 firstValue = GetCurrentValue(0);
            DisplayValues.CopyFrom(firstValue);

            for (int i = 1; i < Targets.Length; i++)
            {
                Vector3 otherValue = GetCurrentValue(i);
                if (otherValue.x != firstValue.x) DisplayValues.x = null;
                if (otherValue.y != firstValue.y) DisplayValues.y = null;
                if (otherValue.z != firstValue.z) DisplayValues.z = null;
            }
        }

        /************************************************************************************************************************/

#if PRO
        private static readonly int BoxHash = "Box".GetHashCode();
#endif

        protected float? MultiFloatField(SerializedProperty property, Color color, GUIContent label, float? value, float snapValue, float defaultValue)
        {
            var position = EditorGUILayout.GetControlRect(InternalGUI.VectorFieldOptions);
            position.width += 2;

            EditorGUI.BeginChangeCheck();
            EditorGUI.BeginProperty(position, label, property);

#if PRO
            // Emphasize non-default fields.
            if (EmphasizeNonDefaultFields && (value == null || value.Value != defaultValue))
            {
                const float Border = 1;
                Rect box = new Rect(position);
                box.xMin += EditorGUIUtility.labelWidth - Border;
                box.y -= Border;
                box.width += Border;
                box.height += Border * 2;

                GUI.color = Color.white;
                GUI.Box(box, GUIContent.none);
            }
            else
            {
                // If we didn't draw the box, get a control ID to make sure that the field's ID is consistent between showing and not showing the box.
                GUIUtility.GetControlID(BoxHash, FocusType.Passive);
            }

            // Field Colors.
            if (UseFieldColors)
#endif
                GUI.color = color;

            float fieldValue;
            if (value != null)
            {
                fieldValue = value.Value;
                EditorGUI.showMixedValue = false;
            }
            else
            {
                fieldValue = 0;
                EditorGUI.showMixedValue = true;
            }

#if PRO
            // Italic for properties which aren't multiples of their snap threshold.
            if (ItaliciseNonSnappedFields &&
                !EditorGUI.showMixedValue &&
                !InspectorGadgetsUtils.IsSnapped(fieldValue, snapValue))
            {
                InternalGUI.FloatFieldStyle.fontStyle = FontStyle.Italic;
            }
#endif

            // Draw the number field.
            fieldValue = EditorGUI.FloatField(position, label, fieldValue, InternalGUI.FloatFieldStyle);

            // Revert any style changes.
            InternalGUI.FloatFieldStyle.fontStyle = FontStyle.Normal;

            EditorGUI.showMixedValue = false;

            EditorGUI.EndProperty();
            if (EditorGUI.EndChangeCheck())
                return fieldValue;

            // Middle click a field to revert to the default value.
            if (UseMiddleClickInLastRect())
                value = defaultValue;

            return value;
        }

        private static void SetFieldColor(Color color)
        {
#if PRO
            if (UseFieldColors)
#endif
                GUI.color = color;
        }

        /************************************************************************************************************************/

        private void CheckInspectorClipboardHotkeys(int startID)
        {
            int endID = GUIUtility.GetControlID(FocusType.Passive);

            if (GUIUtility.keyboardControl > startID && GUIUtility.keyboardControl < endID)
            {
                var currentEvent = Event.current;
                if (currentEvent.type == EventType.KeyUp &&
                    currentEvent.control &&
                    !EditorGUIUtility.editingTextField)
                {
                    switch (currentEvent.keyCode)
                    {
                        case KeyCode.C:
                            CopyCurrentValueToClipboard();
                            Event.current.Use();
                            break;
                        case KeyCode.V:
                            PasteValueFromClipboard();
                            Event.current.Use();
                            break;
                    }
                }
            }
        }

        /************************************************************************************************************************/

        private static Transform[] _UndoTargets;

        protected void RecordTargetsForUndo(string name)
        {
            if (ParentEditor.CurrentFreezeChildTransforms)
            {
                int count = Targets.Length;
                for (int i = 0; i < Targets.Length; i++)
                {
                    count += Targets[i].childCount;
                }

                Array.Resize(ref _UndoTargets, count);

                count = 0;
                for (int i = 0; i < Targets.Length; i++)
                {
                    Transform target = Targets[i];

                    _UndoTargets[count++] = target;

                    for (int j = 0; j < target.childCount; j++)
                    {
                        _UndoTargets[count++] = target.GetChild(j);
                    }
                }

                Undo.RecordObjects(_UndoTargets, name);
            }
            else
            {
                Undo.RecordObjects(Targets, name);
            }
        }

        protected void RecordTransformForUndo(Transform target, string name)
        {
            if (ParentEditor.CurrentFreezeChildTransforms)
            {
#if PRO
                if (TransformEditor.DrawAllGizmos)
                {
                    Array.Resize(ref _UndoTargets, target.childCount + 1);

                    int i = 0;
                    for (; i < target.childCount; i++)
                    {
                        _UndoTargets[i] = target.GetChild(i);
                    }
                    _UndoTargets[i] = target;
                }
                else
#endif
                {
                    int count = ParentEditor.Targets.Length;
                    for (int i = 0; i < ParentEditor.Targets.Length; i++)
                    {
                        count += ParentEditor.Targets[i].childCount;
                    }

                    Array.Resize(ref _UndoTargets, count);

                    int index = 0;
                    for (int i = 0; i < ParentEditor.Targets.Length; i++)
                    {
                        target = ParentEditor.Targets[i];
                        for (int j = 0; j < target.childCount; j++)
                        {
                            _UndoTargets[index++] = target.GetChild(j);
                        }
                        _UndoTargets[index++] = target;
                    }
                }

                Undo.RecordObjects(_UndoTargets, name);
            }
#if PRO
            else if (TransformEditor.DrawAllGizmos)
            {
                Undo.RecordObject(target, name);
            }
#endif
            else
            {
                Undo.RecordObjects(ParentEditor.Targets, name);
            }
        }

        /************************************************************************************************************************/

        public abstract void DrawTool(Transform target, Vector3 handlePosition);

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Mini Buttons
        /************************************************************************************************************************/

        private void DoMiniButtons()
        {
            DoCopyButton();
            DoPasteButton();
            DoSnapButton();
            DoResetButton();
        }

        /************************************************************************************************************************/
        #region Copy
        /************************************************************************************************************************/

        private void DoCopyButton()
        {
#if PRO
            if (!ShowCopyButton)
                return;
#endif

            bool enabled = GUI.enabled;
            if (enabled) DisableGuiIfCopyIsUseless();

            if (GUILayout.Button(InternalGUI.Copy, InternalGUI.SmallButtonStyle))
            {
                if (Event.current.button == 1)
                {
                    LogCurrentValue();
                }
                else
                {
                    CopyCurrentValueToClipboard();
                }
            }

            GUI.enabled = enabled;
        }

        /************************************************************************************************************************/

        private void DisableGuiIfCopyIsUseless()
        {
#if PRO
            if (!DisableUselessButtons)
                return;
#endif

            if (Event.current.type != EventType.Repaint)
                return;

            if (DisplayValues != Clipboard ||
#if UNITY_5_6_OR_LATER
                !DisplayValues.Equals(SerializedPropertyContextMenu.Vector3MenuHandler.Clipboard, 3) ||
#endif
                DisplayValues.AllNull(3))
                return;

            GUI.enabled = false;
        }

        /************************************************************************************************************************/

        private void LogCurrentValue()
        {
            StringBuilder message = new StringBuilder();
            var target = Targets[0];
            if (Targets.Length == 1)
            {
                message.Append(target.name);
                message.Append('.');
                message.Append(ParentEditor.CurrentIsLocalMode ? "Local" : "World");
                message.Append(LocalLabel.text);
                message.Append(" = ");
                message.Append(GetCurrentValue(target));
            }
            else
            {
                message.Append("Selection.");
                message.Append(ParentEditor.CurrentIsLocalMode ? "Local" : "World");
                message.Append(LocalLabel.text);
                message.Append("s = ");
                message.Append(Targets.Length);
                message.AppendLine(" values:");

                for (int i = 0; i < Targets.Length; i++)
                    message.Append('[').Append(i).Append("] ").Append(GetCurrentValue(i)).AppendLine();
            }
            Debug.Log(message, target);
        }

        /************************************************************************************************************************/

        private void CopyCurrentValueToClipboard()
        {
            Clipboard.CopyFrom(DisplayValues);
            UpdatePasteTooltip();
#if UNITY_5_6_OR_LATER
            SerializedPropertyContextMenu.Vector3MenuHandler.Clipboard = new NullableVector4(DisplayValues);
#endif
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Paste
        /************************************************************************************************************************/

        private void DoPasteButton()
        {
#if PRO
            if (!ShowPasteButton)
                return;
#endif

            bool enabled = GUI.enabled;
            if (enabled) DisableGuiIfPasteIsUseless();

            if (GUILayout.Button(PasteContent, InternalGUI.SmallButtonStyle))
            {
                GUIUtility.keyboardControl = 0;

#if UNITY_5_6_OR_LATER
                if (Event.current.button == 1)
                {
                    PasteValue(Clipboard);
                }
                else
                {
                    PasteValueFromClipboard();
                }
#else
                PasteValue(Clipboard);
#endif
            }

            GUI.enabled = enabled;
        }

        /************************************************************************************************************************/

        private void DisableGuiIfPasteIsUseless()
        {
#if PRO
            if (!DisableUselessButtons)
                return;
#endif

            if (Event.current.type != EventType.Repaint)
                return;

            if (DisplayValues != Clipboard ||
#if UNITY_5_6_OR_LATER
                !DisplayValues.Equals(SerializedPropertyContextMenu.Vector3MenuHandler.Clipboard, 3) ||
#endif
                Clipboard.AllNull(3))
                return;

            GUI.enabled = false;
        }

        /************************************************************************************************************************/

        protected virtual void PasteValue(NullableVector4 clipboard)
        {
            RecordTargetsForUndo("Paste " + LocalLabel.text);

            for (int i = 0; i < Targets.Length; i++)
            {
                var target = Targets[i];
                if (target == null)
                    continue;

                SetCurrentValue(target, clipboard);
            }
        }

        private void PasteValueFromClipboard()
        {
            PasteValue(SerializedPropertyContextMenu.Vector3MenuHandler.Clipboard);
        }

        /************************************************************************************************************************/

        private void UpdatePasteTooltip()
        {
#if UNITY_5_6_OR_LATER
            PasteContent.tooltip = "Left Click = Paste (public): " + SerializedPropertyContextMenu.Vector3MenuHandler.Clipboard.ToString(3) +
                "\nRight Click = Paste (private): " + Clipboard.ToString(3);
#else
            PasteContent.tooltip = "Paste: " + Clipboard.ToString(3);
#endif
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Snap
        /************************************************************************************************************************/

        private void DoSnapButton()
        {
#if PRO
            if (!ShowSnapButton)
                return;
#endif

            bool enabled = GUI.enabled;
            if (enabled) DisableGuiIfSnapIsUseless();

            if (GUILayout.Button(SnapContent, InternalGUI.SmallButtonStyle))
            {
                GUIUtility.keyboardControl = 0;

                if (Event.current.button == 1)
                {
                    EditorApplication.ExecuteMenuItem("Edit/Snap Settings...");
                }
                else
                {
                    RecordTargetsForUndo("Snap " + LocalLabel.text);

                    for (int i = 0; i < Targets.Length; i++)
                    {
                        var target = Targets[i];
                        SetCurrentValue(target, SnapValue(GetCurrentValue(target)));
                    }
                }
            }

            GUI.enabled = enabled;
        }

        /************************************************************************************************************************/

        private void DisableGuiIfSnapIsUseless()
        {
#if PRO
            if (!DisableUselessButtons)
                return;
#endif

            if (Event.current.type != EventType.Repaint)
                return;

            var snap = SnapValues;
            for (int i = 0; i < Targets.Length; i++)
            {
                Vector3 value = GetCurrentValue(i);
                if (!InspectorGadgetsUtils.IsSnapped(value.x, snap.x) ||
                    !InspectorGadgetsUtils.IsSnapped(value.y, snap.y) ||
                    !InspectorGadgetsUtils.IsSnapped(value.z, snap.z))
                {
                    return;
                }
            }

            GUI.enabled = false;
        }

        /************************************************************************************************************************/

        protected abstract string GetSnapTooltip();

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #region Reset
        /************************************************************************************************************************/

        private void DoResetButton()
        {
#if PRO
            if (!ShowResetButton)
                return;

            bool enabled = GUI.enabled;
            if (enabled) DisableGuiIfResetIsUseless();

            if (GUILayout.Button(InternalGUI.Reset, InternalGUI.SmallButtonStyle))
            {
                GUIUtility.keyboardControl = 0;

                ResetToDefaultValue();
            }

            GUI.enabled = enabled;
#endif
        }

        /************************************************************************************************************************/

        private void DisableGuiIfResetIsUseless()
        {
#if PRO
            if (!DisableUselessButtons)
                return;
#endif

            if (Event.current.type != EventType.Repaint)
                return;

            for (int i = 0; i < Targets.Length; i++)
            {
                if (GetCurrentValue(i) != DefaultValue)
                {
                    return;
                }
            }

            GUI.enabled = false;
        }

        /************************************************************************************************************************/

        protected virtual void ResetToDefaultValue()
        {
            RecordTargetsForUndo("Reset " + LocalLabel.text);

            for (int i = 0; i < Targets.Length; i++)
            {
                SetCurrentValue(i, DefaultValue);
            }
        }

        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
        #endregion
        /************************************************************************************************************************/
    }
}

#endif