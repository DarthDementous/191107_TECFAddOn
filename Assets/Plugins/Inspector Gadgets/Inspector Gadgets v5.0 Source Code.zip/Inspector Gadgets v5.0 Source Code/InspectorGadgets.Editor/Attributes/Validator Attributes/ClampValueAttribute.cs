﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// Specifies the range of values allowed by the attributed int or float field.
    /// See also: <see cref="MinValueAttribute"/> and <see cref="MaxValueAttribute"/>.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class ClampValueAttribute : ValidatorAttribute
    {
        private readonly int MinInt;
        private readonly float MinFloat;

        private readonly int MaxInt;
        private readonly float MaxFloat;

        /// <summary>
        /// Constructs a new <see cref="ClampValueAttribute"/> with the specified range.
        /// </summary>
        public ClampValueAttribute(int min, int max)
        {
            MinInt = min;
            MinFloat = min;

            MaxInt = max;
            MaxFloat = max;

            Debug.Assert(min < max, "min must be less than max");
        }

        /// <summary>
        /// Constructs a new <see cref="ClampValueAttribute"/> with the specified range.
        /// </summary>
        public ClampValueAttribute(float min, float max)
        {
            MinInt = (int)min;
            MinFloat = min;

            MaxInt = (int)max;
            MaxFloat = max;

            Debug.Assert(min < max, "min must be less than max");
        }

#if UNITY_EDITOR && PRO
        /// <summary>
        /// Validate the value of the specified 'property'.
        /// </summary>
        public override void Validate(UnityEditor.SerializedProperty property)
        {
            if (property.propertyType == UnityEditor.SerializedPropertyType.Integer)
            {
                var value = property.intValue;
                if (value < MinInt)
                    property.intValue = MinInt;
                else if (value > MaxInt)
                    property.intValue = MaxInt;
            }
            else if (property.propertyType == UnityEditor.SerializedPropertyType.Float)
            {
                var value = property.floatValue;
                if (value < MinFloat)
                    property.floatValue = MinFloat;
                else if (value > MaxFloat)
                    property.floatValue = MaxFloat;
            }
        }
#endif
    }
}