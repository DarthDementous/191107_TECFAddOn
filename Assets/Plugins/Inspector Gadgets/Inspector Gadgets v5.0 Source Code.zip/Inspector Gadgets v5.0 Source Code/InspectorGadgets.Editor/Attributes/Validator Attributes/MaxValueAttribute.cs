﻿// Inspector Gadgets // Copyright 2018 Kybernetik //


namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// Specifies the maximum value allowed by the attributed int or float field.
    /// See also: <see cref="MinValueAttribute"/> and <see cref="ClampValueAttribute"/>.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class MaxValueAttribute : ValidatorAttribute
    {
        private readonly int MaxInt;
        private readonly float MaxFloat;

        /// <summary>
        /// Constructs a new <see cref="MaxValueAttribute"/> with a maximum value of 0.
        /// </summary>
        public MaxValueAttribute() { }

        /// <summary>
        /// Constructs a new <see cref="MaxValueAttribute"/> with the specified maximum value.
        /// </summary>
        public MaxValueAttribute(int max)
        {
            MaxInt = max;
            MaxFloat = max;
        }

        /// <summary>
        /// Constructs a new <see cref="MaxValueAttribute"/> with the specified maximum value.
        /// </summary>
        public MaxValueAttribute(float max)
        {
            MaxInt = (int)max;
            MaxFloat = max;
        }

#if UNITY_EDITOR && PRO
        /// <summary>
        /// Validate the value of the specified 'property'.
        /// </summary>
        public override void Validate(UnityEditor.SerializedProperty property)
        {
            if (property.propertyType == UnityEditor.SerializedPropertyType.Integer)
            {
                if (property.intValue > MaxInt)
                    property.intValue = MaxInt;
            }
            else if (property.propertyType == UnityEditor.SerializedPropertyType.Float)
            {
                if (property.floatValue > MaxFloat)
                    property.floatValue = MaxFloat;
            }
        }
#endif
    }
}