﻿// Inspector Gadgets // Copyright 2018 Kybernetik //


namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// Specifies the minimum value allowed by the attributed int or float field.
    /// See also: <see cref="MaxValueAttribute"/> and <see cref="ClampValueAttribute"/>.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class MinValueAttribute : ValidatorAttribute
    {
        private readonly int MinInt;
        private readonly float MinFloat;

        /// <summary>
        /// Constructs a new <see cref="MinValueAttribute"/> with a minimum value of 0.
        /// </summary>
        public MinValueAttribute() { }

        /// <summary>
        /// Constructs a new <see cref="MinValueAttribute"/> with the specified minimum value.
        /// </summary>
        public MinValueAttribute(int min)
        {
            MinInt = min;
            MinFloat = min;
        }

        /// <summary>
        /// Constructs a new <see cref="MinValueAttribute"/> with the specified minimum value.
        /// </summary>
        public MinValueAttribute(float min)
        {
            MinInt = (int)min;
            MinFloat = min;
        }

#if UNITY_EDITOR && PRO
        /// <summary>
        /// Validate the value of the specified 'property'.
        /// </summary>
        public override void Validate(UnityEditor.SerializedProperty property)
        {
            if (property.propertyType == UnityEditor.SerializedPropertyType.Integer)
            {
                if (property.intValue < MinInt)
                    property.intValue = MinInt;
            }
            else if (property.propertyType == UnityEditor.SerializedPropertyType.Float)
            {
                if (property.floatValue < MinFloat)
                    property.floatValue = MinFloat;
            }
        }
#endif
    }
}