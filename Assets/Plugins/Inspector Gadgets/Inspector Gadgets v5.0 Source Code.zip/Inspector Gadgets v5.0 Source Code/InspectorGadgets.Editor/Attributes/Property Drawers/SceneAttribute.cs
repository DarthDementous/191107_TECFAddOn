﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using System;
using System.IO;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// Causes the attributed int or string field to be drawn as a dropdown box for selecting scenes from the build settings.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class SceneAttribute : PropertyAttribute { }

    /************************************************************************************************************************/

#if UNITY_EDITOR && PRO
    [CustomPropertyDrawer(typeof(SceneAttribute))]
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class SceneDrawer : PropertyDrawer
    {
        /************************************************************************************************************************/

        private static bool _IsListeningForSceneListChange;
        private static EditorBuildSettingsScene[] _AllScenes;
        private static readonly List<string> ActiveScenes = new List<string>();
        private static readonly GUIContent ButtonContent = new GUIContent();

        /************************************************************************************************************************/

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            GatherScenes();

            position = EditorGUI.IndentedRect(position);

            var width = position.width;

            float labelWidth = EditorGUIUtility.labelWidth + 14;

            position.xMax = labelWidth;
            GUI.Label(position, label);

            position.width = width;
            position.xMin = labelWidth;

            string buttonLabel;
            switch (property.propertyType)
            {
                case SerializedPropertyType.Integer:

                    int value = property.intValue;

                    if (value >= 0 && value < ActiveScenes.Count)
                        buttonLabel = ActiveScenes[value];
                    else
                        buttonLabel = "None";

                    ButtonContent.text = value + ": " + buttonLabel;
                    ButtonContent.tooltip = buttonLabel;

                    if (DrawButton(position))
                        ShowIndexPopup(buttonLabel, property);

                    break;

                case SerializedPropertyType.String:

                    buttonLabel = property.stringValue;
                    ButtonContent.text = buttonLabel;
                    ButtonContent.tooltip = null;

                    if (DrawButton(position))
                        ShowPathPopup(buttonLabel, property);

                    break;

                default:
                    GUI.Label(position, "Invalid [Scene] attribute");
                    break;
            }
        }

        /************************************************************************************************************************/

        private void GatherScenes()
        {
            if (_AllScenes != null)
                return;

            if (!_IsListeningForSceneListChange)
            {
                _IsListeningForSceneListChange = true;
                EditorBuildSettings.sceneListChanged += () =>
                {
                    _AllScenes = null;
                    ActiveScenes.Clear();
                };
            }

            _AllScenes = EditorBuildSettings.scenes;

            for (int i = 0; i < _AllScenes.Length; i++)
            {
                var scene = _AllScenes[i];
                if (scene.enabled)
                    ActiveScenes.Add(scene.path);
            }
        }

        /************************************************************************************************************************/

        private bool DrawButton(Rect position)
        {
            return GUI.Button(position, ButtonContent, EditorStyles.popup);
        }

        /************************************************************************************************************************/

        private void ShowIndexPopup(string selectedLabel, SerializedProperty property)
        {
            GenericMenu menu = new GenericMenu();

            AddMenuItem(menu, "None", selectedLabel, () => property.intValue = -1, property);

            int sceneIndex = 0;
            for (int i = 0; i < _AllScenes.Length; i++)
            {
                var scene = _AllScenes[i];
                if (scene.enabled)
                {
                    int currentSceneIndex = sceneIndex;
                    AddMenuItem(menu, currentSceneIndex + ": " + GetDisplayString(scene.path), selectedLabel, () => property.intValue = currentSceneIndex, property);
                    sceneIndex++;
                }
                else
                {
                    menu.AddDisabledItem(new GUIContent(GetDisplayString(scene.path)));
                }
            }

            menu.ShowAsContext();
        }

        /************************************************************************************************************************/

        private void ShowPathPopup(string selectedLabel, SerializedProperty property)
        {
            GenericMenu menu = new GenericMenu();

            AddMenuItem(menu, "None", selectedLabel, () => property.stringValue = "", property);

            int sceneIndex = 0;
            for (int i = 0; i < _AllScenes.Length; i++)
            {
                var scene = _AllScenes[i];
                string name = Path.GetFileNameWithoutExtension(scene.path);

                if (scene.enabled)
                {
                    AddMenuItem(menu, name, selectedLabel, () => property.stringValue = name, property);
                    sceneIndex++;
                }
                else
                {
                    menu.AddDisabledItem(new GUIContent(name));
                }
            }

            menu.ShowAsContext();
        }

        /************************************************************************************************************************/

        private static string GetDisplayString(string str)
        {
            return str.Replace('/', '\\');
        }

        /************************************************************************************************************************/

        private static void AddMenuItem(GenericMenu menu, string label, string selectedLabel, Action method, SerializedProperty property)
        {
            menu.AddItem(new GUIContent(label), label == selectedLabel, () =>
            {
                method();
                property.serializedObject.ApplyModifiedProperties();
            });
        }

        /************************************************************************************************************************/

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return EditorGUIUtility.singleLineHeight;
        }

        /************************************************************************************************************************/
    }
#endif
}