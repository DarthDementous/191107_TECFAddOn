﻿//// Inspector Gadgets // Copyright 2018 Kybernetik //

//using System.Reflection;
//using UnityEngine;

//namespace InspectorGadgets
//{
//    /// <summary>[Pro-Only]
//    /// Causes the attributed field to be drawn with a button to browse for a file or directory path.
//    /// </summary>
//    [System.Diagnostics.Conditional("UNITY_EDITOR")]
//    public abstract class PathField : PropertyAttribute
//    {
//        /************************************************************************************************************************/
//#if UNITY_EDITOR && PRO
//        /************************************************************************************************************************/

//        public abstract string Browse(string title, string path);

//        /************************************************************************************************************************/

//        protected virtual string GetDefaultDirectory()
//        {
//            return System.Environment.CurrentDirectory;
//        }

//        /************************************************************************************************************************/
//#endif
//        /************************************************************************************************************************/

//        public sealed class File : PathField
//        {
//            /************************************************************************************************************************/

//            public string Extension { get; set; }

//            /************************************************************************************************************************/
//#if UNITY_EDITOR && PRO
//            /************************************************************************************************************************/

//            private static readonly AutoPrefs.EditorString
//                LastPathFieldDirectory = new AutoPrefs.EditorString(InspectorGadgetsUtils.PrefsKeyPrefix + nameof(LastPathFieldDirectory) + "." + nameof(File));

//            /************************************************************************************************************************/

//            public override string Browse(string displayName, string path)
//            {
//                string title = "[" + GetType().Name + "] " + displayName;

//                if (string.IsNullOrEmpty(path))
//                    path = GetDefaultDirectory();

//                return UnityEditor.EditorUtility.OpenFilePanel(title, path, Extension);
//            }

//            /************************************************************************************************************************/
//#endif
//            /************************************************************************************************************************/
//        }

//        /************************************************************************************************************************/
//    }

//    /************************************************************************************************************************/

//#if UNITY_EDITOR && PRO
//    [UnityEditor.CustomPropertyDrawer(typeof(PathField), true)]
//    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
//    internal sealed class PathFieldDrawer : ObjectDrawer
//    {
//        /************************************************************************************************************************/

//        public override void OnGUI(Rect position, UnityEditor.SerializedProperty property, GUIContent label)
//        {
//            if (property.propertyType != UnityEditor.SerializedPropertyType.String)
//            {
//                base.OnGUI(position, property, label);
//                Debug.LogWarning("[" + nameof(PathField) + "] properties can only be used on string fields.");
//                return;
//            }

//            const float ButtonWidth = 20;

//            position.width -= ButtonWidth;
//            base.OnGUI(position, property, label);

//            position.x += position.width;
//            position.width = ButtonWidth;
//            if (GUI.Button(position, "..."))
//            {
//                (attribute as PathField).Browse(property.displayName, property.stringValue);
//            }
//        }

//        /************************************************************************************************************************/
//    }
//#endif
//}