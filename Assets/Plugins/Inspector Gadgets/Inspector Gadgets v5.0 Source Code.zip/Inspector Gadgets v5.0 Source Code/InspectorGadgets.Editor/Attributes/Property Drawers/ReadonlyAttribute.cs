﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

#if UNITY_EDITOR
using System.Reflection;
using UnityEditor;
#endif
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// Causes the attributed field to be greyed out and un-editable in the inspector.
    /// </summary>
    [System.Diagnostics.Conditional("UNITY_EDITOR")]
    public sealed class ReadonlyAttribute : PropertyAttribute
    {
        /// <summary>
        /// Indicates when the field should be greyed out.
        /// </summary>
        public readonly EditorState When;

        /// <summary>
        /// Constructs a new <see cref="ReadonlyAttribute"/> to apply its effects in the specified <see cref="EditorState"/>.
        /// </summary>
        public ReadonlyAttribute(EditorState when = EditorState.Always)
        {
            When = when;
        }
    }

    /************************************************************************************************************************/

#if UNITY_EDITOR && PRO
    [CustomPropertyDrawer(typeof(ReadonlyAttribute))]
    [Obfuscation(Exclude = false, Feature = "-rename", ApplyToMembers = false)]
    internal sealed class ReadonlyDrawer : ObjectDrawer
    {
        /************************************************************************************************************************/

        public override void OnGUI(Rect position, SerializedProperty property, GUIContent label)
        {
            var attribute = this.attribute as ReadonlyAttribute;

            bool enabled = GUI.enabled;
            GUI.enabled = !attribute.When.IsNow();
            base.OnGUI(position, property, label);
            GUI.enabled = enabled;
        }

        /************************************************************************************************************************/

        public override float GetPropertyHeight(SerializedProperty property, GUIContent label)
        {
            return EditorGUI.GetPropertyHeight(property, label, true);
        }

        /************************************************************************************************************************/
    }
#endif
}