﻿// Inspector Gadgets // Copyright 2018 Kybernetik //

using System;
using System.Reflection;
using UnityEngine;
using Object = UnityEngine.Object;

namespace InspectorGadgets
{
    /// <summary>[Pro-Only]
    /// <see cref="Editor{T}"/> uses this attribute to add a button at the bottom of the default inspector to run the marked method.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public class ButtonAttribute : BaseInspectableAttribute
    {
        /************************************************************************************************************************/

        /// <summary>If true, clicking the button will automatically call <see cref="UnityEditor.EditorUtility.SetDirty"/> after invoking the method.</summary>
        public bool SetDirty { get; set; }

        /************************************************************************************************************************/
#if UNITY_EDITOR && PRO
        /************************************************************************************************************************/

        private MethodInfo _Method;

        /// <summary>Initialise this button with a method.</summary>
        protected override void Initialise(MemberInfo member)
        {
            _Method = member as MethodInfo;

            if (Label == null)
                Label = InspectorGadgetsUtils.ConvertCamelCaseToFriendly(_Method.Name);

            if (Tooltip == null)
                Tooltip = "Calls " + _Method.GetNameCS();
        }

        /************************************************************************************************************************/

        /// <summary>Draw this button using <see cref="GUILayout"/>.</summary>
        public override void OnGUI(Object[] targets)
        {
            if (GUILayout.Button(Label, UnityEditor.EditorStyles.miniButton))
            {
                if (_Method.IsStatic)// Static Method.
                {
                    object result = _Method.Invoke(null, null);

                    if (SetDirty)
                        foreach (var target in targets)
                            UnityEditor.EditorUtility.SetDirty(target);

                    if (_Method.ReturnType != typeof(void))
                        Debug.Log(Label + ": " + result);
                }
                else// Instance Method.
                {
                    foreach (var target in targets)
                    {
                        object result = _Method.Invoke(target, null);

                        if (SetDirty)
                            UnityEditor.EditorUtility.SetDirty(target);

                        if (_Method.ReturnType != typeof(void))
                            Debug.Log(Label + ": " + result, target);
                    }
                }
            }
        }

        /************************************************************************************************************************/
#endif
        /************************************************************************************************************************/
    }
}