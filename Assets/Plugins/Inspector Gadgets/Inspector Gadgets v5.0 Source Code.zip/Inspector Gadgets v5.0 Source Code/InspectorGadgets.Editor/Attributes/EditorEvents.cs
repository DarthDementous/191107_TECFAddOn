// Inspector Gadgets // Copyright 2018 Kybernetik //

using System;
using System.Reflection;
using UnityEngine;

namespace InspectorGadgets
{
    /// <summary>
    /// Registers a static parameterless method to be called when the Unity Editor unloads its assemblies, such as
    /// after recompiling the user's scripts when preparing to load the newly compiled code.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class OnWillUnloadAssembliesAttribute : Attribute { }

    /// <summary>
    /// Registers a static parameterless method to be called when the Unity Editor is closed.
    /// <para></para>
    /// Note that the method must be declared in a non-generic class.
    /// </summary>
    [AttributeUsage(AttributeTargets.Method)]
    public sealed class OnEditorQuitAttribute : Attribute { }

#if UNITY_EDITOR

    [ExecuteInEditMode]
    [AddComponentMenu("")]
    [DisallowMultipleComponent]
    internal sealed class EditorEvents : MonoBehaviour
    {
        /************************************************************************************************************************/

        private static EditorEvents _Instance;

        /************************************************************************************************************************/

        [UnityEditor.InitializeOnLoadMethod]
        private static void CreateInstance()
        {
            if (_Instance is null)
                new GameObject(nameof(EditorEvents), typeof(EditorEvents));
        }

        /************************************************************************************************************************/

        private void OnEnable()
        {
            if (_Instance is null)
            {
                _Instance = this;
                gameObject.hideFlags = HideFlags.HideAndDontSave;
            }
            else
            {
                DestroyImmediate(gameObject);
            }
        }

        private void OnDisable()
        {
            if (!ReferenceEquals(this, _Instance))
                return;

            ExecuteMethodsWithAttribute<OnWillUnloadAssembliesAttribute>();
        }

        /************************************************************************************************************************/

        private void OnDestroy()
        {
            if (!ReferenceEquals(this, _Instance))
                return;

            ExecuteMethodsWithAttribute<OnEditorQuitAttribute>();
        }

        /************************************************************************************************************************/

        private static void ExecuteMethodsWithAttribute<T>() where T : Attribute
        {
            InspectorGadgetsUtils.ForEachTypeInDependantAssemblies(typeof(T).Assembly, (type) =>
            {
                if (type.IsGenericTypeDefinition)
                    return;

                var methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
                for (int j = 0; j < methods.Length; j++)
                {
                    var method = methods[j];

                    if (method.IsGenericMethod ||
                        !method.IsDefined(typeof(T), false) ||
                        method.GetParameters().Length != 0)
                        continue;

                    try
                    {
                        method.Invoke(null, null);
                    }
                    catch (Exception ex)
                    {
                        Debug.LogException(ex);
                    }
                }
            });
            //var thisAssembly = typeof(T).Assembly;
            //ExecuteMethodsWithAttribute<T>(thisAssembly);

            //string name = thisAssembly.GetName().Name;

            //// For each currently loaded assembly.
            //var assemblies = AppDomain.CurrentDomain.GetAssemblies();
            //for (int i = 0; i < assemblies.Length; i++)
            //{
            //    var assembly = assemblies[i];
            //    if (assembly == thisAssembly)
            //        continue;

            //    var references = assembly.GetReferencedAssemblies();
            //    for (int j = 0; j < references.Length; j++)
            //    {
            //        // If that assembly references this assembly, find and call any [OnEditorQuit] methods.
            //        if (references[j].Name == name)
            //        {
            //            ExecuteMethodsWithAttribute<T>(assembly);
            //            break;
            //        }
            //    }
            //}
        }

        /************************************************************************************************************************/

        //private static void ExecuteMethodsWithAttribute<T>(Assembly assembly) where T : Attribute
        //{
        //    var types = assembly.GetTypes();
        //    for (int i = 0; i < types.Length; i++)
        //    {
        //        var type = types[i];
        //        if (type.IsGenericTypeDefinition)
        //            continue;

        //        var methods = type.GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static);
        //        for (int j = 0; j < methods.Length; j++)
        //        {
        //            var method = methods[j];

        //            if (method.IsGenericMethod ||
        //                !method.IsDefined(typeof(T), false) ||
        //                method.GetParameters().Length != 0)
        //                continue;

        //            try
        //            {
        //                method.Invoke(null, null);
        //            }
        //            catch (Exception ex)
        //            {
        //                Debug.LogException(ex);
        //            }
        //        }
        //    }
        //}

        /************************************************************************************************************************/
    }

#endif
}